﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Styles
{
  /// <summary>
  /// Interaction logic for Sample3_ResourcesDynamic.xaml
  /// </summary>
  public partial class Sample3_ResourcesDynamic : Window
  {
    public Sample3_ResourcesDynamic() {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e) {
      ResourceDictionary rd = new ResourceDictionary();
      string resource = null;

      try {
        // Set the source of the new Resource Dictionary
        resource = string.Format("/WPFResources;component/Resources/{0}", txtXamlName.Text);
        rd.Source = new Uri(resource, UriKind.RelativeOrAbsolute);
        // Clear any previous dictionaries loaded
        Resources.MergedDictionaries.Clear();
        // Add in newly loaded Resource Dictionary
        Resources.MergedDictionaries.Add(rd);
      }
      catch (Exception ex) {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
