﻿using System.Windows;

namespace WPF_Styles
{
  /// <summary>
  /// Interaction logic for Sample3_TemplatesButtonVSM.xaml
  /// </summary>
  public partial class Sample3_TemplatesButtonVSM : Window
  {
    public Sample3_TemplatesButtonVSM() {
      InitializeComponent();
    }
  }
}
