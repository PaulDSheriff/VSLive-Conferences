﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Styles
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow() {
      InitializeComponent();
    }

    private void btnFundSample1_Click(object sender, RoutedEventArgs e) {
      Sample1_HardCodedStyles win = new Sample1_HardCodedStyles();

      win.Show();
    }

    private void btnFundSample2_Click(object sender, RoutedEventArgs e) {
      Sample2_WindowResources win = new Sample2_WindowResources();

      win.Show();
    }

    private void btnFundSample3_Click(object sender, RoutedEventArgs e) {
      Sample3_StackPanelResources win = new Sample3_StackPanelResources();

      win.Show();
    }

    private void btnKeyedSample1_Click(object sender, RoutedEventArgs e) {
      Sample1_KeyedStyles win = new Sample1_KeyedStyles();

      win.Show();
    }

    private void btnKeyedSample2_Click(object sender, RoutedEventArgs e) {
      Sample2_BasedOnStyles win = new Sample2_BasedOnStyles();

      win.Show();
    }

    private void btnKeyedSample3_Click(object sender, RoutedEventArgs e) {
      Sample3_OverrideStyles win = new Sample3_OverrideStyles();

      win.Show();
    }

    private void btnDictSample1_Click(object sender, RoutedEventArgs e) {
      Sample1_ResourceDictionary win = new Sample1_ResourceDictionary();

      win.Show();
    }

    private void btnDictSample2_Click(object sender, RoutedEventArgs e) {
      Sample2_ResourcesFromDLL win = new Sample2_ResourcesFromDLL();

      win.Show();
    }

    private void btnDictSample3_Click(object sender, RoutedEventArgs e) {
      Sample3_ResourcesDynamic win = new Sample3_ResourcesDynamic();

      win.Show();
    }

    private void btnTmplSample1_Click(object sender, RoutedEventArgs e) {
      Sample1_TemplatesTooltips win = new Sample1_TemplatesTooltips();

      win.Show();
    }

    private void btnTmplSample2_Click(object sender, RoutedEventArgs e) {
      Sample2_TemplatesButton win = new Sample2_TemplatesButton();

      win.Show();
    }

    private void btnTmplSample3_Click(object sender, RoutedEventArgs e) {
      Sample3_TemplatesButtonVSM win = new Sample3_TemplatesButtonVSM();

      win.Show();
    }
  }
}
