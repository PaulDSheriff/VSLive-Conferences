﻿using System;

namespace CS_Debug
{
  public class Employee
  {
    #region Constructors
    public Employee()
    {
    }

    public Employee(string firstName)
    {
      FirstName = firstName;
    }
    #endregion

    public int id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    public bool IsValid()
    {
      return (LastName.Trim() != string.Empty);
    }
  }
}
