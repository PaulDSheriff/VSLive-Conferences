﻿using System;
using System.Diagnostics;
using System.Windows;

namespace CS_Debug
{
	public partial class winDebugClass : Window
	{
		public winDebugClass()
		{
			InitializeComponent();
		}

		private void btnWriteLine_Click(object sender, RoutedEventArgs e)
		{
			WriteLineSample();
		}

		private void WriteLineSample()
		{
			Debug.Write("No CRLF after this...");
			Debug.WriteLine("Number: " + txtNumber.Text);
		}

		private void btnWriteLineIf_Click(object sender, RoutedEventArgs e)
		{
			WriteLineIfSample();
		}

		private void WriteLineIfSample()
		{
			int num;

			num = Convert.ToInt32(txtNumber.Text);
			Debug.WriteLineIf(num >= 0 && num <= 5,
				"You input a correct number");
		}

		private void btnAssert_Click(object sender, RoutedEventArgs e)
		{
			AssertSample();
		}

		private void AssertSample()
		{
			int num;

			num = Convert.ToInt32(txtNumber.Text);
			Debug.Assert(num >= 0 && num <= 5,
				"Number must be between 0 and 5", "This assertion occurred in the btnAssert_Click event procedure in the winDebugClass window.");
		}
	}
}
