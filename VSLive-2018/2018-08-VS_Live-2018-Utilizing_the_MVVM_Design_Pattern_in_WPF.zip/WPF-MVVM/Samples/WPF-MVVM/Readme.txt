﻿To run this sample, create the tables using the \SqlScripts\WPFLab.sql file

You might have to change the connection string in the App.config file to point to the correct server and database
