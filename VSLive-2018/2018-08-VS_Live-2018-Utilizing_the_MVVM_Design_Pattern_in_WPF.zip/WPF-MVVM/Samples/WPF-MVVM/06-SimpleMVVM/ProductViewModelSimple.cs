﻿using System;
using System.Collections.ObjectModel;
using Common.Library;

namespace WPF_MVVM
{
  public class ProductViewModelSimple : ViewModelBase
  {
    #region Constructor
    public ProductViewModelSimple() : base() {
      LoadAll();
    }
    #endregion

    #region Private UI Variables
    private bool _IsAddMode = false;
    private bool _IsSaveEnabled = false;
    private bool _IsCancelEnabled = false;
    private bool _IsAddEnabled = true;
    private bool _IsListEnabled = true;
    private bool _IsDetailEnabled = false;
    private int _SelectedListIndex = -1;

    private string _Message = string.Empty;
    private ObservableCollection<Product> _DataCollection;
    private Product _DetailData;
    #endregion

    #region UI Properties
    public bool IsSaveEnabled
    {
      get { return _IsSaveEnabled; }
      set
      {
        if (_IsSaveEnabled != value)
        {
          _IsSaveEnabled = value;
          RaisePropertyChanged("IsSaveEnabled");
        }
      }
    }

    public bool IsCancelEnabled
    {
      get { return _IsCancelEnabled; }
      set
      {
        if (_IsCancelEnabled != value)
        {
          _IsCancelEnabled = value;
          RaisePropertyChanged("IsCancelEnabled");
        }
      }
    }

    public bool IsAddEnabled
    {
      get { return _IsAddEnabled; }
      set
      {
        if (_IsAddEnabled != value)
        {
          _IsAddEnabled = value;
          RaisePropertyChanged("IsAddEnabled");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public int SelectedListIndex
    {
      get { return _SelectedListIndex; }
      set
      {
        if (_SelectedListIndex != value)
        {
          _SelectedListIndex = value;
          RaisePropertyChanged("SelectedListIndex");
        }
      }
    }

    public bool IsDetailEnabled
    {
      get { return _IsDetailEnabled; }
      set
      {
        if (_IsDetailEnabled != value)
        {
          _IsDetailEnabled = value;
          RaisePropertyChanged("IsDetailEnabled");
        }
      }
    }

    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region SetListMode Method
    public void SetListMode()
    {
      IsAddMode = false;
      IsAddEnabled = true;
      IsSaveEnabled = false;
      IsCancelEnabled = false;
      IsListEnabled = true;
      IsDetailEnabled = false;
    }
    #endregion

    #region SetModifyMode Method
    public void SetModifyMode()
    {
      IsAddEnabled = false;
      IsSaveEnabled = true;
      IsCancelEnabled = true;
      IsListEnabled = false;
      IsDetailEnabled = true;
      Message = string.Empty;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      try
      {
        ProductManager mgr = new ProductManager();

        DataCollection = new ObservableCollection<Product>(mgr.GetProducts());
        SelectedListIndex = 0;

      }
      catch
      {
        // Ignore exception in design time
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord()
    {
      SetModifyMode();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit()
    {
      SetListMode();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData()
    {
      if (IsAddMode)
      {
        InsertData();
      }
      else
      {
        UpdateData();
      }

      SetListMode();
    }
    #endregion

    #region Insert Data
    public void InsertData()
    {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Insert Product
      resp = mgr.Insert(DetailData);
      if (resp.Status == OperationResult.Exception)
      {
        Message = resp.ErrorMessage;
      }
      else
      {
        DataCollection.Add(DetailData);
        Message = "Insert Successful";
      }
    }
    #endregion

    #region Update Data
    public void UpdateData()
    {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Update Product
      resp = mgr.Update(DetailData);
      if (resp.Status == OperationResult.Exception)
      {
        Message = resp.ErrorMessage;
      }
      else
      {
        Message = "Update Successful";
      }
    }
    #endregion
  }
}
