﻿using System.Windows;
using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class winSimpleMVVM : Window
  {
    public winSimpleMVVM() {
      InitializeComponent();

      _ViewModel = (ProductViewModelSimple)this.Resources["viewModel"];
    }

    private ProductViewModelSimple _ViewModel = null;

    private void btnEdit_Click(object sender, RoutedEventArgs e) {
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      _ViewModel.SetModifyMode();
    }

    private void btnAdd_Click(object sender, RoutedEventArgs e) {
      _ViewModel.AddRecord();
    }

    private void btnSave_Click(object sender, RoutedEventArgs e) {
      _ViewModel.SaveData();

    }

    private void btnCancel_Click(object sender, RoutedEventArgs e) {
      _ViewModel.CancelEdit();

      // TODO: Write code to undo changes
    }
  }
}
