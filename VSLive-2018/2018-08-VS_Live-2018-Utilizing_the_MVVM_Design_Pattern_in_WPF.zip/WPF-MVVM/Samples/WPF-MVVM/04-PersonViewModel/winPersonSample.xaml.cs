﻿using System.Windows;

namespace WPF_MVVM
{
  public partial class winPersonSample : Window
  {
    public winPersonSample()
    {
      InitializeComponent();

      _ViewModel = (PersonViewModel)this.Resources["viewModel"];
    }

    PersonViewModel _ViewModel = null;

    private void Button_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Validate();
    }
  }
}
