﻿using Common.Library;
using System;
using System.Collections.ObjectModel;
using System.Text;

namespace WPF_MVVM
{
  public class PersonViewModel : ViewModelBase
  {
    #region Constructor
    public PersonViewModel() : base() {
      PersonData = new Person();
    }
    #endregion

    #region Private Variables
    private ObservableCollection<BusinessRuleMessage> _BusinessRuleFailures;
    private Person _PersonData;
    #endregion
       
    #region Public Properties
    public ObservableCollection<BusinessRuleMessage> BusinessRuleFailures
    {
      get { return _BusinessRuleFailures; }
      set
      {
        _BusinessRuleFailures = value;
        RaisePropertyChanged("BusinessRuleFailures");
      }
    }

    public Person PersonData
    {
      get { return _PersonData; }
      set
      {
        _PersonData = value;
        RaisePropertyChanged("PersonData");
      }
    }
    #endregion

    #region Validate Method
    public bool Validate() {
      IsMessageVisible = false;
      Message = string.Empty;
      StringBuilder sb = new StringBuilder(1024);

      if (PersonData.Validate() == false) {
        IsMessageVisible = true;
        BusinessRuleFailures = PersonData.BusinessRuleFailures;
      }

      return !IsMessageVisible;
    }
    #endregion
  }
}