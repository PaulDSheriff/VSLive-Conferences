﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Library;

namespace WPF_MVVM
{
  public class SimpleBindingViewModel : CommonBase
  {
    private bool _IsBenefitsChecked = true;
    private bool _Is401kEnabled = true;
    private bool _IsHealthCareEnabled = true;

    public bool IsBenefitsChecked
    {
      get { return _IsBenefitsChecked; }
      set
      {
        if (_IsBenefitsChecked != value)
        {
          _IsBenefitsChecked = value;
          Is401kEnabled = value;
          IsHealthCareEnabled = value;
          RaisePropertyChanged("IsBenefitsChecked");
        }
      }
    }

    public bool Is401kEnabled
    {
      get { return _Is401kEnabled; }
      set
      {
        if (_Is401kEnabled != value)
        {
          _Is401kEnabled = value;
          RaisePropertyChanged("Is401kEnabled");
        }
      }
    }

    public bool IsHealthCareEnabled
    {
      get { return _IsHealthCareEnabled; }
      set
      {
        if (_IsHealthCareEnabled != value)
        {
          _IsHealthCareEnabled = value;
          RaisePropertyChanged("IsHealthCareEnabled");
        }
      }
    }
  }
}
