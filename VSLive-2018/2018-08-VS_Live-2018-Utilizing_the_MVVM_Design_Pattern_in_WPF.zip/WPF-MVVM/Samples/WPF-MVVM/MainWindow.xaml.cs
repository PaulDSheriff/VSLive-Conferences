﻿using System.Windows;

namespace WPF_MVVM
{
  public partial class MainWindow : Window
  {
    public MainWindow() {
      InitializeComponent();
    }

    private void btnSimpleBinding_Click(object sender, RoutedEventArgs e) {
      winSimpleBinding win = new winSimpleBinding();

      win.Show();
    }

    private void btnSimpleBindingViewModel_Click(object sender, RoutedEventArgs e) {
      winSimpleBindingViewModel win = new winSimpleBindingViewModel();

      win.Show();
    }

    private void btnSearch_Click(object sender, RoutedEventArgs e) {
      winSearchSample win = new winSearchSample();

      win.Show();
    }

    private void btnPerson_Click(object sender, RoutedEventArgs e) {
      winPersonSample win = new winPersonSample();

      win.Show();
    }

    private void btnSimpleViewModelList_Click(object sender, RoutedEventArgs e) {
      winListOnly win = new winListOnly();

      win.Show();
    }

    private void btnSimpleViewModel_Click(object sender, RoutedEventArgs e) {
      winSimpleMVVM win = new winSimpleMVVM();

      win.Show();
    }

    private void btnSimpleBaseClass_Click(object sender, RoutedEventArgs e) {
      winProducts win = new winProducts();

      win.Show();
    }
  }
}
