﻿
namespace Common.Library
{
  public class BusinessRuleMessage : CommonBase
  {
    #region Constructors
    public BusinessRuleMessage() : base()
    {
    }

    public BusinessRuleMessage(string propertyName, string message) : base() {
      PropertyName = propertyName;
      Message = message;
    }
    #endregion

    private string _PropertyName;
    private string _Message;

    /// <summary>
    /// Get/Set PropertyName
    /// </summary>
    public string PropertyName
    {
      get { return _PropertyName; }
      set
      {
        if (_PropertyName != value) {
          _PropertyName = value;
          RaisePropertyChanged("PropertyName");
        }
      }
    }

    /// <summary>
    /// Get/Set Message
    /// </summary>
    public string Message
    {
      get { return _Message; }
      set
      {
        if (_Message != value) {
          _Message = value;
          RaisePropertyChanged("Message");
        }
      }
    }
  }
}
