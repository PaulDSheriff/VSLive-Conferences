﻿
namespace Common.Library
{
  public class ViewModelBase : CommonBase
  {
    private string _Message = string.Empty;
    private bool _IsMessageVisible = false;
    
    public string Message
    {
      get { return _Message; }
      set
      {
        _Message = value;
        RaisePropertyChanged("Message");
      }
    }

    public bool IsMessageVisible
    {
      get { return _IsMessageVisible; }
      set
      {
        _IsMessageVisible = value;
        RaisePropertyChanged("IsMessageVisible");
      }
    }
  }
}
