﻿using System.Collections.Generic;

namespace WPF_MVVM
{
  public class ProductResponse : ResponseBase
  {
    public Product DetailData { get; set; }

    public List<Product> DataCollection { get; set; }
  }
}
