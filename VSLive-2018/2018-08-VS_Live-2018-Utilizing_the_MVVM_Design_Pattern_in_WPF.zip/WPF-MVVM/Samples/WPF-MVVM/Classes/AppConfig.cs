﻿using System.Configuration;

namespace WPF_MVVM
{
  public class AppConfig
  {
    private static AppConfig _Instance = null;
    public static AppConfig Instance
    {
      get
      {
        if (_Instance == null) {
          _Instance = new AppConfig();
        }

        return _Instance;
      }
      set { _Instance = value; }
    }

    public string ConnectString
    {
      get { return ConfigurationManager.ConnectionStrings["Sandbox"].ConnectionString; }
    }
  }

}
