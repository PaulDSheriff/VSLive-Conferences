﻿
using System.Collections.ObjectModel;

namespace Common.Library
{
  public class DataClassBase : CommonBase
  {
    public DataClassBase() {
      _BusinessRuleFailures = new ObservableCollection<BusinessRuleMessage>();
    }

    private ObservableCollection<BusinessRuleMessage> _BusinessRuleFailures;

    public ObservableCollection<BusinessRuleMessage> BusinessRuleFailures
    {
      get { return _BusinessRuleFailures; }
      set
      {
        _BusinessRuleFailures = value;
        RaisePropertyChanged("BusinessRuleFailures");
      }
    }
  }
}
