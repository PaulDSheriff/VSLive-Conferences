﻿
namespace WPF_MVVM
{
  public enum OperationResult
  {
    Unknown,
    Success,
    Exception,
    Failure
  }

  public class ResponseBase
  {
    public ResponseBase()
    {
      Status = OperationResult.Unknown;
      FriendlyErrorMessage = string.Empty;
      ErrorMessage = string.Empty;
    }

    public OperationResult Status { get; set; }

    public string FriendlyErrorMessage { get; set; }

    public string ErrorMessage { get; set; }
  }
}
