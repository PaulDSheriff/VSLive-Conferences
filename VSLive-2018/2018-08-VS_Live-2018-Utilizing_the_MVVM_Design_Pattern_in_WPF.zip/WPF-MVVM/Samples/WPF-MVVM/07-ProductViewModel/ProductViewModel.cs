﻿using System;
using System.Collections.ObjectModel;
using Common.Library;

namespace WPF_MVVM
{
  public class ProductViewModel : ViewModelAddEditDeleteBase
  {  
    #region Private UI Variables
    private ObservableCollection<Product> _DataCollection;
    private Product _DetailData;
    #endregion

    #region DataCollection Property
    public ObservableCollection<Product> DataCollection
    {
      get { return _DataCollection; }
      set
      {
        _DataCollection = value;
        RaisePropertyChanged("DataCollection");
      }
    }
    #endregion

    #region DetailData Property
    public Product DetailData
    {
      get { return _DetailData; }
      set
      {
        _DetailData = value;
        RaisePropertyChanged("DetailData");
      }
    }
    #endregion

    #region LoadAll Method
    public void LoadAll() {
      try {
        ProductManager mgr = new ProductManager();

        DataCollection = new ObservableCollection<Product>(mgr.GetProducts());
        SelectedListIndex = 0;
      }
      catch {
        // Ignore exception in design time
      }
    }
    #endregion

    #region AddRecord Method
    public void AddRecord() {
      SetModifyMode();
      IsAddMode = true;

      // Create Empty Object for UI to Display
      DetailData = new Product();
      DetailData.IntroductionDate = DateTime.Now;
      DetailData.IsDiscontinued = false;
    }
    #endregion

    #region CancelEdit Method
    public void CancelEdit() {
      SetListMode();

      IsAddMode = false;
      Message = string.Empty;

      // TODO: Write Code to Undo Here
    }
    #endregion

    #region SaveData Method
    public void SaveData() {
      if (IsAddMode) {
        InsertData();
      }
      else {
        UpdateData();
      }

      SetListMode();
    }
    #endregion

    #region Insert Data
    public void InsertData() {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Insert Product
      resp = mgr.Insert(DetailData);
      if (resp.Status == OperationResult.Exception) {
        Message = resp.ErrorMessage;
      }
      else {
        DataCollection.Add(DetailData);
        Message = "Insert Successful";
      }
    }
    #endregion

    #region Update Data
    public void UpdateData() {
      ProductManager mgr = new ProductManager();
      ProductResponse resp = default(ProductResponse);

      // Update Product
      resp = mgr.Update(DetailData);
      if (resp.Status == OperationResult.Exception) {
        Message = resp.ErrorMessage;
      }
      else {
        Message = "Update Successful";
      }
    }
    #endregion
  }
}
