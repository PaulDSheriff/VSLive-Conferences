﻿using System.Windows;
using System.Windows.Controls;

namespace WPF_MVVM
{
  public partial class winProducts : Window
  {
    public winProducts()
    {
      InitializeComponent();
      
      // Initialize the Product View Model Object
      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private ProductViewModel _ViewModel;

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      // Load Products explicitly, not using a constructor
      _ViewModel.LoadAll();
    }
    #endregion

    #region Edit Click Event
    private void btnEdit_Click(object sender, RoutedEventArgs e)
    {
      // Get Data Context from Button
      // So you can update the List Box SelectedValue
      _ViewModel.DetailData = (Product)((Button)sender).DataContext;
      _ViewModel.SetModifyMode();
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.AddRecord();
    }
    #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.CancelEdit();

      // TODO: Write code to undo changes
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.SaveData();
    }
    #endregion
  }
}
