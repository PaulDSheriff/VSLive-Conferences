﻿Bootstrap Samples
----------------------------------------------------
These samples illustrate many of the various classes that make up Bootstrap.
We are using bootstrap 4.x.

BreakPoints01.html - Shows the 5 defined breakpoints
Grid01.html - 12 column Grid system
Grid02.html - Using offsets
Grid03.html - More examples of column layouts
Grid04.html - 2 column layout
Grid05.html - Example of using columns

Margin-Padding.html = Show use of 'm' and 'p' classes 

Helper01.html - Text Helper Classes (Color)
Helper02.html - Background Helper Classes (Color)

Button01.html - Button Helper Classes (Color)
Button02.html - Buttons in a Group, as Radio Buttons, as Check Boxes
Button03.html - Toolbar of buttons
Button04.html - Drop Down Buttons

Text01.html - Justification, Capitalization, Address, Full Name and Email
Text02.html - h1, h2, p, Block quote, block quote reverse and other textual components

Image01.html - Use img-responsive to scale pictures
Image02.html - Shaping images
Image03.html - Wrap text around image

Alert01.html - Different colors for alerts
Alert02.html - Make alert appear in response to button click
Alert03.html - Dismissible alert
Alert04.html - Dismiss and make visibile again

Form01.html - Contact Us. Shows usage of radio buttons.
Form02.html - Review Album. Horizontal Form. Shows usage of check boxes and 'text-center'
Form03.html - Login screen. Shows input groups. Font Awesome
Form04.html - Using rows and columns

Card01.html - Header, Body and footer
Card02.html - Just a body
Card03.html - Login screen using a card
Card04.html - Card groups and adding images

Bootstrap Navigation Samples
----------------------------------------------------
These samples illustrate how to create navigation in Bootstrap 4.x.

09-NavBar-Simple
-------------------------------------------------------
Nav01 - Navigation using <nav>
Nav02 - Navigation using <ul>
Nav03 - Centered navigation
Nav04 - Right justified navigation

10-Navbar
-------------------------------------------------------
Navbar01 - Navigation Bar
Navbar02 - Navbar with Drop Down menu
Navbar03 - Styling navbar, container-fluid
Navbar04 - Fixed top
Navbar05 - Fixed bottom, change dropdown to dropup, add padding to bottom

11-SideNav
-------------------------------------------------------
Side01 - Side bar, then switch to horizontal at xs breakpoint
Side02 - Side bar and content, switch from vertical to horizontal at xs breakpoint
Side03 - Side bar with drop-down

