﻿Demos
-------------------------------------------------------------------
Most of these demos work best in Chrome. Sometimes FireFox, Opera or IE 11/Edge may be used.


References
-------------------------------------------------------------------
http://www.w3schools.com/css3/css3_multiple_columns.asp
http://www.w3.org/TR/css3-multicol/
http://www.w3schools.com/css3/css3_user_interface.asp
http://www.w3schools.com/css3/css3_text_effects.asp
http://www.w3schools.com/cssref/css_units.asp
http://www.w3schools.com/css/css_font.asp
http://www.css3.info/preview/resize/
http://www.w3.org/TR/css3-transitions/
http://blogs.msdn.com/b/eternalcoding/archive/2011/12/06/css3-transitions.aspx

CSS Flex Box
https://www.w3schools.com/css/css3_flexbox.asp

CSS Grid Layout
https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout/Basic_Concepts_of_Grid_Layout

CSS 3 Browser Support
http://www.w3schools.com/cssref/css3_browsersupport.asp
