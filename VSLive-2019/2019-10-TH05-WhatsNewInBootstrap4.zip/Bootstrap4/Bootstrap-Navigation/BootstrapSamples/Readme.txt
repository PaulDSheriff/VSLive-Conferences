﻿Bootstrap Navigation Samples
----------------------------------------------------
These samples illustrate how to create navigation in Bootstrap 4.x.

01-Simple
-------------------------------------------------------
Nav01 - Navigation using <nav>
Nav02 - Navigation using <ul>
Nav03 - Centered navigation
Nav04 - Right justified navigation

02-Navbar
-------------------------------------------------------
Navbar01 - Navigation Bar
Navbar02 - Navbar with Drop Down menu
Navbar03 - Styling navbar, container-fluid
Navbar04 - Fixed top
Navbar05 - Fixed bottom, change dropdown to dropup, add padding to bottom

03-SideNav
-------------------------------------------------------
Side01 - Side bar, then switch to horizontal at xs breakpoint
Side02 - Side bar and content, switch from vertical to horizontal at xs breakpoint

Side03 - ** TODO: Side bar with drop-down
https://www.codeply.com/go/dBrRxEAPBI/bootstrap-4-sidebar-menu-(toggleable)
