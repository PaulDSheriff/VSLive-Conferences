To install the dependencies for this sample open a terminal window and type:
npm install

To run the sample type:
npm run dev