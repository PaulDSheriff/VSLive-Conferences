'use strict';

function aboutHello() {
  alert("Hello from About Page");
}
