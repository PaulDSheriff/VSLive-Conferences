'use strict';

/**
 * Product List Component
 */
var productListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];

  /**
   * Private Functions
   */
  function _get() {
    _dataList = [
      {
        productID: 680,
        name: 'HL Road Frame - Black, 58',
        productNumber: 'FR-R92B-58',
        color: 'Black',
        standardCost: 1059.31,
        listPrice: 1431.50
      },
      {
        productID: 707,
        name: 'Sport-100 Helmet, Red',
        productNumber: 'HL-U509-R',
        color: 'Red',
        standardCost: 13.08,
        listPrice: 34.99
      },
      {
        productID: 709,
        name: 'Mountain Bike Socks, M',
        productNumber: 'SO-B909-M',
        color: 'White',
        standardCost: 3.3963,
        listPrice: 9.50
      }
    ];

    // Create HTML table
    _renderData("#dataTmpl", "#products tbody");
  }

  function _renderData(templateId, insertInto) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, productListComponent);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "get": _get,
    "dataList": function () {
      return _dataList;
    }
  };
})();
