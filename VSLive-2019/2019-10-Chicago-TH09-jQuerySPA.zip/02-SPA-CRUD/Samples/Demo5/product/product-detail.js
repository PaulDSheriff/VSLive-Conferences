'use strict';

/**
 * Product Detail Component
 */
var productDetailComponent = (function () {
  /**
   * Private Variables
   */
  var _entity;

  /**
   * Private Functions
   */ 

  function _get() {
    // Assuming the following url: #detail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Get entity to display
      _getEntity(id);
    }
    else {
      // Create a blank entity for adding
      _newEntity();
    }
  }

  function _getEntity(id) {
    // Call service to get data
    productService.get(id, function (data) {
      // Assign data to object
      _entity = data;
      // Display fields in HTML inputs
      _displayEntity(_entity);
    });
  }


  function _newEntity() {
    // Create new entity and display on screen
    _displayEntity({
      "productID": -1,
      "name": "A New Product",
      "productNumber": "NEW-1",
      "color": "Red",
      "standardCost": 10,
      "listPrice": 20,
      "size": "M",
      "weight": null,
      "sellStartDate": commonComponent.todaysDateToHtml5Input(),
      "sellEndDate": null
    });
  }

  function _save() {
    // Gather data from HTML inputs
    _entity = _getEntityFromInput();

    if (_entity.productID && Number(_entity.productID) >= 0) {
      // Update data
      _updateEntity();
    } 
    else {
      // Add data
      _addEntity();
    }
  }

  function _updateEntity() {
    // Get data from HTML
    _entity = _getEntityFromInput();
    // Call productService to update product
    productService.updateEntity(_entity.productID, _entity, function (data) {
      // Return to list page
      _goBack();
    });
  }

  function _addEntity() {
    // Get data from HTML
    _entity = _getEntityFromInput();
    // Remove productID property
    delete _entity.productID;
   
    // Call productService to update product
    productService.addEntity(_entity, function (data) {
      // Return to list page
      _goBack();
    });
  }

  function _getEntityFromInput() {
    return {
      "productID": $("#productID").val(),
      "name": $("#name").val(),
      "productNumber": $("#productNumber").val(),
      "color": $("#color").val(),
      "standardCost": $("#standardCost").val(),
      "listPrice": $("#listPrice").val(),
      "size": $("#size").val(),
      "weight": $("#weight").val(),
      "sellStartDate": $("#sellStartDate").val(),
      "sellEndDate": $("#sellEndDate").val()
    }
  }
  
  function _displayEntity(product) {
    $("#productID").val(product.productID);
    $("#name").val(product.name);
    $("#productNumber").val(product.productNumber);
    $("#color").val(product.color);
    $("#standardCost").val(product.standardCost);
    $("#listPrice").val(product.listPrice);
    $("#size").val(product.size);
    $("#weight").val(product.weight);
    $("#sellStartDate").val(product.sellStartDate);
    $("#sellEndDate").val(product.sellEndDate);
  }

  function _goBack() {
    window.history.back(-1);
  }

  /**
   * Public Functions
   */
  return {
    "get": _get,
    "save": _save,
    "cancel": _goBack
  };
})();