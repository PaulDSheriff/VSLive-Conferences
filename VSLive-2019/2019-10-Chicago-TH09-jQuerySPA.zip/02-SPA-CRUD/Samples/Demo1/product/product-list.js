'use strict';

/**
 * Product List Component
 */
var productListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];

  /**
   * Private Functions
   */
  function _get() {
     // Call service to get list of data
     productService.getAll(function (data) {
      // Assign data to array
      _dataList = data;
      // Create HTML table
      _renderData("#dataTmpl", "#products tbody");
    });
 }

  function _renderData(templateId, insertInto) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, productListComponent);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "get": _get,
    "dataList": function () {
      return _dataList;
    }
  };
})();
