'use strict';

/**
 * Common Component
 */
let commonComponent = (function () {
  /**
   * Private functions
   */
  function _todaysDateToHtml5Input() {
    var d = new Date(Date.now());
    return d.getFullYear() + "-" + ("0" + (d.getMonth()+1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }

  /**
   * Public functions
   */
  return {
    "todaysDateToHtml5Input": _todaysDateToHtml5Input
  };
})();
