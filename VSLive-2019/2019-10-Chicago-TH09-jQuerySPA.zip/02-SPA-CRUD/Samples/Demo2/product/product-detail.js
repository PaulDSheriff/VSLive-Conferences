'use strict';

/**
 * Product Detail Component
 */
var productDetailComponent = (function () {
  /**
   * Private Variables
   */
  var _entity;

  /**
   * Private Functions
   */
  function _get() {
    // Assuming the following url: #detail/n
    var id = window.location.hash;
    if (id.lastIndexOf("/") >= 0) {
      // Extract the ID portion from the hash
      id = id.substring(id.lastIndexOf("/") + 1);
    }
    else {
      id = null;
    }

    if (id) {
      // Get entity to display
      _getEntity(id);
    }
  }

  function _getEntity(id) {
    // Call service to get data
    productService.get(id, function (data) {
      // Assign data to object
      _entity = data;
      // Display fields in HTML inputs
      _displayEntity(_entity);
    });
  }

  function _displayEntity(product) {
    $("#productID").val(product.productID);
    $("#name").val(product.name);
    $("#productNumber").val(product.productNumber);
    $("#color").val(product.color);
    $("#standardCost").val(product.standardCost);
    $("#listPrice").val(product.listPrice);
    $("#size").val(product.size);
    $("#weight").val(product.weight);
    $("#sellStartDate").val(product.sellStartDate);
    $("#sellEndDate").val(product.sellEndDate);
  }

  function _goBack() {
    window.history.back(-1);
  }

  /**
   * Public Functions
   */
  return {
    "get": _get,
    "cancel": _goBack
  };
})();