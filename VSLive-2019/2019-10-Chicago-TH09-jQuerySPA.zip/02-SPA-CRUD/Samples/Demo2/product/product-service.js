'use strict';

/**
 * Product Service Component
 */
var productService = (function () {
  /**
   * Private variables
   */
  const API_URL = "http://localhost:5000/api/product/";

  /**
   * Private functions
   */
  function _getAll(success, failure) {
    // Get list of data
    $.ajax({
      url: API_URL,
      type: "GET",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  function _get(id, success, failure) {
    // Get a single row of data
    $.ajax({
      url: API_URL + id,
      type: "GET",
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      });
  }

  /**
   * Public functions
   */
  return {
    "getAll": _getAll,
    "get": _get
  };
})();