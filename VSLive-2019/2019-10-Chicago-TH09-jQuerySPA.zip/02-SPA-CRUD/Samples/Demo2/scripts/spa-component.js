'use strict';

$(document).ready(function () {
  spaComponent.init();
});

/**
 * SPA Component
 */
let spaComponent = (function () {
  /**
   * Private functions
   */
  function _init() {
    let pageName = window.location.href;
    let contentElement = "contentarea";
    let start = $(contentElement).data('page-start');

    // Get content area by reading nodeName
    contentElement = $("[data-page-start]") ? $("[data-page-start]")[0].nodeName : contentElement;

    // Trigger home page if there is not already a hash sign
    if (pageName.indexOf("#") == -1) {
      window.location.replace(pageName + start);
    }
    else {
      _changePage(contentElement, pageName.substr(pageName.indexOf("#")));
    }

    // Respond to changes in hash
    window.onhashchange = function () {
      _changePage(contentElement, window.location.hash);
    }
  }

  function _changePage(contentArea, hashValue) {
    // Get path for partial page
    let path = $("a[href='" + hashValue + "']").data("page-path") || "";

    // Remove # to create the page file name
    let pageName = hashValue.substr(1);
    // Remove any trailing data after the slash
    if (pageName.lastIndexOf("/") >= 0) {
      pageName = pageName.substring(0, pageName.lastIndexOf("/"));
    }

    // Set document title
    window.document.title = $("a[href='" + hashValue + "']").attr("title");
    
    // Use jQuery to retrieve partial page
    $(contentArea).load(path + pageName + ".html",
      function (response, status, xhr) {
        if (status == "error") {
          console.error("Can't retrieve partial page: '"
            + pageName + ".html' - " + JSON.stringify(xhr));
        }
        else {
          // Reset menu focus
          _resetMenu(hashValue);
        }
      }
    );
  }

  function _resetMenu(hashValue) {
    // Set focus to menu that matches current page
    $("a[href='" + hashValue + "']").focus();
    // Remove outline around anchor when setting focus
    $("a[href='" + hashValue + "']").css("outline", "0");
  }

  /**
   * Public functions
   */
  return {
    "changePage": _changePage,
    "init": _init
  };
})();