'use strict';

/**
 * Product List Component
 */
var productListComponent = (function () {
  /**
   * Private Variables
   */
  var _dataList = [];
  var _errorObject = {};

  /**
   * Private Functions
   */
  function _onLoad() {
    _get();
  }

  function _get() {
    // Call service to get list of data
    productService.getAll(
      function (data) {
        // Hide error objects
        messageComponent.hideErrorAreas();
        // Display HTML table
        $("#productListArea").removeClass("hidden");
        // Assign data to array
        _dataList = data;
        // Create HTML table
        commonComponent.renderData("#productListTmpl", "#products tbody", productListComponent);
      },
      function (error) {
        _handleError(error);
      });
  }

  function _deleteEntity(id) {
    productService.deleteEntity(id,
      function (data) {
        // Refresh the HTML table
        _get();
      },
      function (error) {
        _handleError(error);
      });
  }

  function _handleError(error) {
    // Build error object
    _errorObject = messageComponent.buildErrorObject(error);
    // Display error information
    messageComponent.displayErrors(productListComponent);
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "onLoad": _onLoad,
    "get": _get,
    "dataList": function () {
      return _dataList;
    },
    "standardCostAsCurrency": function () {
      return commonComponent.numberAsCurrency(this.standardCost);
    },
    "listPriceAsCurrency": function () {
      return commonComponent.numberAsCurrency(this.listPrice);
    },
    "deleteEntity": function (id) {
      if (confirm("Delete this Product?")) {
        _deleteEntity(id);
      }
    },
    "errorList": function () { // Need to expose this to display errors
      return _errorObject.messages;
    }
  };
})();
