'use strict';

/**
 * Product Service Component
 */
var productService = (function () {
  /**
   * Private variables
   */
  const API_URL = commonComponent.settings().apiUrl + "product/";

  /**
   * Private functions
   */
  function _getAll(success, failure) {
    // Get all rows
    commonComponent.callApi(API_URL, "GET", null, success, failure);
  }

  function _get(id, success, failure) {
    // Get a single row
    commonComponent.callApi(API_URL + id, "GET", null, success, failure);
  }

  function _updateEntity(id, entity, success, failure) {
    // Update single row of data
    commonComponent.callApi(API_URL + id, "PUT", entity, success, failure);
  }

  function _addEntity(entity, success, failure) {
    // Add a single row of data
    commonComponent.callApi(API_URL, "POST", entity, success, failure);
  }

  function _deleteEntity(id, success, failure) {
    // Delete a single row of data
    commonComponent.callApi(API_URL + id, "DELETE", null, success, failure);
  }

  /**
   * Public functions
   */
  return {
    "getAll": _getAll,
    "get": _get,
    "updateEntity": _updateEntity,
    "addEntity": _addEntity,
    "deleteEntity": _deleteEntity
  };
})();