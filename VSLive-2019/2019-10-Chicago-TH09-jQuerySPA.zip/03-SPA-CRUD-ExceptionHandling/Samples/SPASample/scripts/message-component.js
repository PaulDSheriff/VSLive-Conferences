'use strict';

/**
 * Message Component
 */
var messageComponent = (function () {
  /**
   * Private variables
   */
  var _errorObject = {
    "messages": [],
    "isValidationError": false
  };

  const ERROR_AREA = "#errorArea";
  const VALIDATION_AREA = "#valErrorArea";

  /**
   * Private functions
   */
  function _buildErrorObject(error) {
    // Reset errorMessage object
    _errorObject.messages = [];
    _errorObject.isValidationError = false;

    // console.log(JSON.stringify(error));

    switch (error.status) {
      case 400:
        if (error.responseJSON) {
          _errorObject.isValidationError = true;
          for (var key in error.responseJSON) {
            // Create list of error messages to display
            _errorObject.messages.push({
                "propertyName": key,
                "message": error.responseJSON[key][0]
              }
            );
          }
        }
        else {
          if (error.responseText) {
            _errorObject.messages.push({ "message": error.responseText });
          }
          else {
            _errorObject.messages.push({ "message": error.statusText });
          }
        }
        break;

      case 404:
        if (error.responseText) {
          _errorObject.messages.push({ "message": error.responseText });
        }
        else {
          _errorObject.messages.push({ "message": "The data you requested was not found" });
        }
        break;

      default:
        _errorObject.messages.push({ "message": "status: " + error.status });
        _errorObject.messages.push({ "message": "statusText: " + error.statusText });
        if (error.responseJSON && error.responseJSON.Message) {
          _errorObject.messages.push({ "message": "exceptionMessage: " + error.responseJSON.Message });
        }
        break;
    }

    return _errorObject;
  }

  function _displayErrors(component, areaToDisplay, templateId, insertInto) {
    areaToDisplay = areaToDisplay || ERROR_AREA;
    templateId = templateId || "#errorTmpl";
    insertInto = insertInto || "#errors";

    // Display error messages
    _displayMessageArea(component, areaToDisplay, templateId, insertInto);
  }

  function _displayValidationErrors(component, areaToDisplay, templateId, insertInto) {
    areaToDisplay = areaToDisplay || VALIDATION_AREA;
    templateId = templateId || "#valErrorTmpl";
    insertInto = insertInto || "#valErrors";

    // Display validation errors
    _displayMessageArea(component, areaToDisplay, templateId, insertInto);
  }

  function _displayMessageArea(component, areaToDisplay, templateId, insertInto) {
    // Make message area visible
    $(areaToDisplay).removeClass("hidden");
    // Render message area
    commonComponent.renderData(templateId, insertInto, component);
    // Scroll to message area
    $("html,body").animate({ scrollTop: $(areaToDisplay).offset().top - 100 }, 'fast');
  }

  function _hideErrorAreas(errorArea, validationArea) {
    errorArea = errorArea || ERROR_AREA;
    validationArea = validationArea || VALIDATION_AREA;

    $(errorArea).addClass("hidden");
    $(validationArea).addClass("hidden");
  }

  /**
   * Public functions
   */
  return {
    "buildErrorObject": _buildErrorObject,
    "displayErrors": _displayErrors,
    "displayValidationErrors": _displayValidationErrors,
    "hideErrorAreas" : _hideErrorAreas
  };
})();