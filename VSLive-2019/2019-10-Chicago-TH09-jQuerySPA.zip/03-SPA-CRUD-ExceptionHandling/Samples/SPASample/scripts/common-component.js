'use strict';

/**
 * Common Component
 */
var commonComponent = (function () {
  /**
   * Private variables
   */
  var _settings = {
    debug: true,
    apiUrl: 'http://localhost:5000/api/'
  };

  /**
   * Private functions
   */
  function _renderData(templateId, insertInto, component) {
    // Get template from script element
    var template = $(templateId).html();
    // Call Mustache passing in the template and the
    // object with collection of data to display
    var html = Mustache.to_html(template, component);
    // Insert the rendered HTML into the DOM
    $(insertInto).html(html);
  }

  function _callApi(url, type, data, success, failure) {
    // Update single row of data
    $.ajax({
      url: url,
      type: type,
      data: JSON.stringify(data),
      contentType: 'application/json'
    })
      .done(function (data) {
        success(data);
      })
      .fail(function (error) {
        if (failure) {
          failure(error);
        }
        else {
          console.error("Error Occurred: " + JSON.stringify(error));
        }
      });
  }

  function _getConfigSettings() {
    return _settings;
  }

  function _numberAsCurrency(value) {
    return new Number(value).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
  }

  function _todaysDateToHtml5Input() {
    var d = new Date(Date.now());
    return d.getFullYear() + "-" + ("0" + (d.getMonth()+1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }

  /**
   * Public functions
   */
  return {
    "renderData": _renderData,
    "callApi" : _callApi,
    "settings" : _getConfigSettings,
    "numberAsCurrency": _numberAsCurrency,
    "todaysDateToHtml5Input": _todaysDateToHtml5Input
  };
})();