﻿These demos work best in the latest versions of Chrome, FireFox, Opera browser or IE 10 or later

Samples folder
------------------------
Semantic Elements
Structural Elements
Input Types
Attributes
API


HTML 5 Shiv
https://github.com/aFarkas/html5shiv

HTML 5 Tutorial
http://www.w3schools.com/html5/default.asp

New in HTML 5
http://www.w3.org/TR/html5-diff/

What's New in CSS 3
http://www.css3.info/preview/

HTML 5 Migration Notes
https://www.w3schools.com/html/html5_migration.asp

HTML 5 Tester
http://www.html5test.com

HTML Tags Deprecated
https://www.tutorialspoint.com/html5/html5_deprecated_tags.htm