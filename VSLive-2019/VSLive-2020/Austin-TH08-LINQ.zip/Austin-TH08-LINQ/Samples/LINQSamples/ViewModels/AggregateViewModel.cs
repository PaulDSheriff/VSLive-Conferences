﻿using System.Linq;
using Common.Library;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class AggregateViewModel : ViewModelBase
  {
    #region Count
    public void Count()
    {
      int value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Count();
      }
      else {
        // Method Syntax
        value = Products.Count();
      }

      ResultText = $"Total Products = {value}";
      Products = null;
    }
    #endregion

    #region CountFiltered
    public void CountFiltered()
    {
      int value;

      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 where prod.Color == "Red"
                 select prod).Count();
      }
      else {
        // Method Syntax
        value = Products.Count(prod => prod.Color == "Red");
      }

      ResultText = $"Total Products with a color of 'Red' = {value}";
      Products = null;
    }
    #endregion

    #region Sum
    public void Sum()
    {
      decimal? value;
      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Sum();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Sum();
      }

      if (value.HasValue) {
        ResultText = $"Total of all List Prices = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Minimum
    public void Minimum()
    {
      decimal? value;
      Products = new ProductManager().GetAll();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Min();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Min();
      }

      if (value.HasValue) {
        ResultText = $"Minimum List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Maximum
    public void Maximum()
    {
      decimal? value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Max();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Max();
      }

      if (value.HasValue) {
        ResultText = $"Maximum List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Average
    public void Average()
    {
      decimal? value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod.ListPrice).Average();
      }
      else {
        // Method Syntax
        value = Products.Select(prod => prod.ListPrice).Average();
      }

      if (value.HasValue) {
        ResultText = $"Average List Price = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist.";
      }
      Products = null;
    }
    #endregion

    #region Aggregate
    public void Aggregate()
    {
      decimal? value = 0;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Aggregate(0M, (sum, prod) =>
                                             prod.Color == "Black" ? sum += prod.ListPrice.Value : sum);
      }
      else {
        // Method Syntax
        value = Products.Aggregate(0M, (sum, prod) =>
                                        prod.Color == "Black" ? sum += prod.ListPrice.Value : sum);
      }

      if (value.HasValue) {
        ResultText = $"Total List Price of Color is 'Black' = {value.Value.ToString("c")}";
      }
      else {
        ResultText = "No List Prices Exist for the Color 'Black'.";
      }
      Products = null;
    }
    #endregion
  }
}
