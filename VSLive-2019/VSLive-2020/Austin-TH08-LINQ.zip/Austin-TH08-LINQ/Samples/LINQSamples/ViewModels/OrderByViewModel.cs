﻿using System.Data;
using System.Linq;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class OrderByViewModel : ViewModelBase
  {
    #region OrderBy
    public void OrderBy()
    {
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderBy(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region OrderByDescending Method
    public void OrderByDescending()
    {
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Name descending
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderByDescending(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region OrderByTwoFields Method
    public void OrderByTwoFields()
    {
      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in Products
                    orderby prod.Color descending, prod.Name
                    select prod).ToList();
      }
      else {
        // Method Syntax
        Products = Products.OrderByDescending(prod => prod.Color)
                           .ThenBy(prod => prod.Name).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
