﻿using System.Collections.Generic;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;
using LINQSamples.ManagerClasses;

namespace LINQSamples.ViewModels
{
  public class ComparisonViewModel : ViewModelBase
  {
    #region SequenceEqual
    public void SequenceEqual()
    {
      bool value;
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      // Uncomment the following to produce a 'False' value
      // list1.RemoveAt(0);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in list1
                 select prod).SequenceEqual(list1, pc);
      }
      else {
        // Method Syntax
        value = list1.SequenceEqual(list2, pc);
      }

      if (value) {
        ResultText = "Lists are Equal";
      }
      else {
        ResultText = "Lists are NOT Equal";
      }
      Products = null;
    }
    #endregion

    #region Except
    public void Except()
    {
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list2.RemoveAll(prod => prod.Color == "Black");
     
      // NOTE: Except() produces those products not in the other list

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Except(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Except(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Intersect
    public void Intersect()
    {
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");
      
      // NOTE: Intersect() produces those products in common between two lists

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Intersect(list2, pc).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Intersect(list2, pc).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Union
    public void Union()
    {
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");

      // NOTE: Union() combines two lists together, but skips duplicates

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Union(list2, pc).OrderBy(prod => prod.ProductID).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Union(list2, pc).OrderBy(prod => prod.ProductID).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region Concat
    public void Concat()
    {
      ProductIdComparer pc = new ProductIdComparer();
      List<Product> list1 = new ProductManager().GetAll();
      List<Product> list2 = new ProductManager().GetAll();

      list1.RemoveAll(prod => prod.Color == "Black");
      list2.RemoveAll(prod => prod.Color == "Red");

      // NOTE: Concat() combines two lists together and does NOT check for duplicates

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in list1
                    select prod).Concat(list2).OrderBy(prod => prod.ProductID).ToList();
      }
      else {
        // Method Syntax
        Products = list1.Concat(list2).OrderBy(prod => prod.ProductID).ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
