﻿using System.Data;
using System.Linq;
using Common.Library;
using LINQSamples.EntityClasses;

namespace LINQSamples.ViewModels
{
  public class ContainsViewModel : ViewModelBase
  {
    #region All
    public void All()
    {
      bool value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).All(prod => prod.Name.Contains(" "));
      }
      else {
        // Method Syntax
        value = Products.All(prod => prod.Name.Contains(" "));
      }

      ResultText = $"Do all Name properties contain a space? {value}";
      Products = null;
    }
    #endregion

    #region Any
    public void Any()
    {
      bool value;

      LoadProductsCollection();

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Any(prod => prod.Name.Contains("z"));
      }
      else {
        // Method Syntax
        value = Products.Any(prod => prod.Name.Contains("z"));
      }

      ResultText = $"Do any Name properties contain an 'z'? {value}";
      Products = null;
    }
    #endregion

    #region Contains
    public void Contains()
    {
      bool value;
      ProductIdComparer pc = new ProductIdComparer();
      Product prodToFind = new Product { ProductID = 706 };

      LoadProductsCollection();
            
      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in Products
                 select prod).Contains(prodToFind, pc);
      }
      else {
        // Method Syntax
        value = Products.Contains(prodToFind, pc);
      }

      ResultText = $"Product ID: 706 is in Products Collection = {value}";
      Products = null;
    }
    #endregion
  }
}
