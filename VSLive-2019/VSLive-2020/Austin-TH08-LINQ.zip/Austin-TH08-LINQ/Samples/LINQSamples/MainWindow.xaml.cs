﻿using System.Windows;

namespace LINQSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }

    private void Select_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SelectControl());
    }

    private void OrderBy_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new OrderByControl());
    }

    private void Searching_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new SearchControl());
    }

    private void Aggregates_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new AggregateControl());
    }

    private void Contains_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ContainsControl());
    }

    private void Comparisons_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ComparisonControl());
    }

    private void Iteration_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new IterationControl());
    }
  }
}
