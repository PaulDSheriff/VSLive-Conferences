﻿Select
----------------------
GetAll
Specific Columns
Anonymous Class
Distinct
Join
GroupBy
Grouped Subquery

Order By
----------------------
OrderBy
OrderBy (Desc)
OrderBy Two Fields

Searching
--------------------
Where
Find
First
FirstOrDefault
Last
LastOrDefault
Single
SingleOrDefault

Aggregates
-------------------
Count
Count (Filtered)
Sum
Min
Max
Average
Aggregate

Contains
--------------------
All
Any
Contains

Comparisons
--------------------
SequenceEqual
Except
Intersect
Union (No dupes)
Concat (dupes)

Iteration
--------------------
ForEach
Skip
SkipWhile
Take
TakeWhile


Resources
----------------------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/