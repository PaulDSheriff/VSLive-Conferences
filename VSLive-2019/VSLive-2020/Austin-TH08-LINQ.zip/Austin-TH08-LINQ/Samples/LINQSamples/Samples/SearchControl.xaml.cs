﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class SearchControl : UserControl
  {
    public SearchControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (SearchViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly SearchViewModel _viewModel = null;

    private void Where_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.WhereClause();
    }

    private void Find_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Find();
    }

    private void First_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.First();
    }

    private void FirstOrDefault_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.FirstOrDefault();
    }

    private void Last_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Last();
    }

    private void LastOrDefault_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.LastOrDefault();
    }

    private void Single_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Single();
    }

    private void SingleOrDefault_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SingleOrDefault();
    }
  }
}
