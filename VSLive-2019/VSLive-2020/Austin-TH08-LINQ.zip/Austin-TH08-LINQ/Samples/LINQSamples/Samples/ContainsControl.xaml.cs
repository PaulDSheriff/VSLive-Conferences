﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class ContainsControl : UserControl
  {
    public ContainsControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (ContainsViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly ContainsViewModel _viewModel = null;

    private void All_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.All();
    }

    private void Any_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Any();
    }

    private void Contains_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Contains();
    }
  }
}
