﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class AggregateControl : UserControl
  {
    public AggregateControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (AggregateViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly AggregateViewModel _viewModel = null;

    private void CountButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Count();
    }

    private void CountFilteredButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.CountFiltered();
    }

    private void SumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Sum();
    }

    private void MinimumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Minimum();
    }

    private void MaximumButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Maximum();
    }

    private void AverageButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Average();
    }

    private void AggregateButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Aggregate();
    }
  }
}
