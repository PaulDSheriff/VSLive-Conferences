﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class OrderByControl : UserControl
  {
    public OrderByControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (OrderByViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly OrderByViewModel _viewModel = null;

    private void OrderBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderBy();
    }

    private void OrderByDesc_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderByDescending();
    }

    private void OrderByTwoFields_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderByTwoFields();
    }
  }
}
