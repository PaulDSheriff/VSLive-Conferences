﻿using Common.Library;

namespace LINQSamples.EntityClasses
{
  public class SalesOrderDetail : CommonBase
  {
    private int _SalesOrderID;
    private int _SalesOrderDetailID;
    private short _OrderQty;
    private int _ProductID;
    private decimal _UnitPrice;
    private decimal _UnitPriceDiscount;
    private decimal _LineTotal;

    public int SalesOrderID
    {
      get { return _SalesOrderID; }
      set {
        _SalesOrderID = value;
        RaisePropertyChanged("SalesOrderID");
      }
    }

    public int SalesOrderDetailID
    {
      get { return _SalesOrderDetailID; }
      set {
        _SalesOrderDetailID = value;
        RaisePropertyChanged("SalesOrderDetailID");
      }
    }

    public short OrderQty
    {
      get { return _OrderQty; }
      set {
        _OrderQty = value;
        RaisePropertyChanged("OrderQty");
      }
    }

    public int ProductID
    {
      get { return _ProductID; }
      set {
        _ProductID = value;
        RaisePropertyChanged("ProductID");
      }
    }

    public decimal UnitPrice
    {
      get { return _UnitPrice; }
      set {
        _UnitPrice = value;
        RaisePropertyChanged("UnitPrice");
      }
    }

    public decimal UnitPriceDiscount
    {
      get { return _UnitPriceDiscount; }
      set {
        _UnitPriceDiscount = value;
        RaisePropertyChanged("UnitPriceDiscount");
      }
    }

    public decimal LineTotal
    {
      get { return _LineTotal; }
      set {
        _LineTotal = value;
        RaisePropertyChanged("LineTotal");
      }
    }
  }
}
