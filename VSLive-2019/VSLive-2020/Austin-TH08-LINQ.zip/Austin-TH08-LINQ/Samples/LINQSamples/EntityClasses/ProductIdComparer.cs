﻿using System.Collections.Generic;

namespace LINQSamples.EntityClasses
{
  public class ProductIdComparer : IEqualityComparer<Product>
  {
    public bool Equals(Product x, Product y)
    {
      return (x.ProductID == y.ProductID);
    }

    public int GetHashCode(Product obj)
    {
      return obj.ProductID.GetHashCode();
    }
  }
}
