﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class LinqEFControl : UserControl
  {
    public LinqEFControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (LinqEFViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly LinqEFViewModel _viewModel = null;

    private void GetAll_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }

    private void GetSpecific_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetSpecificColumns();
    }

    private void Anonymous_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.AnonymousClass();
    }

    private void Distinct_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Distinct();
    }

    private void Join_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Join();
    }

    private void GroupBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupBy();
    }
    
    private void Subquery_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GroupedSubquery();
    }

    private void Where_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.WhereClause();
    }

    private void OrderBy_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderBy();
    }

    private void OrderByDesc_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.OrderByDescending();
    }

    private void FirstOrDefault_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.FirstOrDefault();
    }

    private void LastOrDefault_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.LastOrDefault();
    }

    private void Count_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Count();
    }

    private void Sum_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Sum();
    }

    private void All_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.All();
    }

    private void Any_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.Any();
    }

    private void SkipWhile_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.SkipWhile();
    }

    private void TakeWhile_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.TakeWhile();
    }
  }
}
