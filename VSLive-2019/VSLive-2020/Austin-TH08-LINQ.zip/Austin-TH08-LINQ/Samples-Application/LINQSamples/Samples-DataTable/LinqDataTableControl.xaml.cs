﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class LinqDataTableControl : UserControl
  {
    public LinqDataTableControl()
    {
      InitializeComponent();
      // Connect to instance of the view model created by the XAML
      _viewModel = (LinqDataTableViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly LinqDataTableViewModel _viewModel = null;

    private void GetAllButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetAll();
    }
  }
}
