﻿LINQ Samples
==============================================================
The DataTable and EF samples require the use of the AdventureWorksLT database
You can get this database at https://github.com/PaulDSheriff/AdventureWorksLT


Samples-Strings
--------------------------------------------------------------
Copy the BlogPost.txt contents into the OriginalText
  Copy the words "the,and,of" into UpToCharacter

Samples-FileIO
--------------------------------------------------------------
Samples showing using LINQ with File IO
Copy the folder 'D:\Training\WebClient\JavaScript\18-APIs' twice
Rename one folder to 'Folder1' and the other to 'Folder2'
Delete one or two files from 'Folder2'
  
Samples-XML
--------------------------------------------------------------
Samples using Linq to XML

Samples-DataTable
--------------------------------------------------------------
Samples using a DataSet/DataTable

Samples-EF
--------------------------------------------------------------
Samples using Entity Framework


Resources
----------------------------------------------------------------
https://docs.microsoft.com/en-us/dotnet/csharp/linq/