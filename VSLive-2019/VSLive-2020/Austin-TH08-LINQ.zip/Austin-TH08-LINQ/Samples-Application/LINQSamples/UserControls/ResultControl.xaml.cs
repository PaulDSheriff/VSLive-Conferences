﻿using System.Windows.Controls;

namespace LINQSamples.UserControls
{
  public partial class ResultControl : UserControl
  {
    public ResultControl()
    {
      InitializeComponent();
    }
  }
}
