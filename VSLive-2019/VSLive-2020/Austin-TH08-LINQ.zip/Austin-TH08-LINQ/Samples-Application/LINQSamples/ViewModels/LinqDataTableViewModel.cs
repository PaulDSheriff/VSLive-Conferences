﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class LinqDataTableViewModel : CommonBase
  {
    #region Constants/Properties
    private List<Product> _Products;

    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      DataTable dt;
      string sql = "SELECT [ProductID],[Name],[ProductNumber],[Color],[StandardCost],[ListPrice],[Size],[Weight],[SellStartDate],[SellEndDate],[DiscontinuedDate] FROM [SalesLT].[Product]";

      dt = GetDataTable(sql);

      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in dt.AsEnumerable()
                    select new Product
                    {
                      ProductID = prod.Field<int>("ProductID"),
                      Name = prod.Field<string>("Name"),
                      ProductNumber = prod.Field<string>("ProductNumber"),
                      Color = prod.Field<string>("Color"),
                      StandardCost = prod.Field<decimal?>("StandardCost"),
                      ListPrice = prod.Field<decimal?>("ListPrice"),
                      Size = prod.Field<string>("Size"),
                      Weight = prod.Field<decimal?>("Weight")
                    }).ToList();
      }
      else {
        // Method Syntax
        Products = dt.AsEnumerable().Select(prod => new Product
        {
          ProductID = prod.Field<int>("ProductID"),
          Name = prod.Field<string>("Name"),
          ProductNumber = prod.Field<string>("ProductNumber"),
          Color = prod.Field<string>("Color"),
          StandardCost = prod.Field<decimal?>("StandardCost"),
          ListPrice = prod.Field<decimal?>("ListPrice"),
          Size = prod.Field<string>("Size"),
          Weight = prod.Field<decimal?>("Weight")
        }).ToList();
      }
    }
    #endregion

    #region GetDataTable
    public DataTable GetDataTable(string sql)
    {
      DataTable ret = null;

      // Create a connection
      using (SqlConnection ConnectionObject = new SqlConnection(AppSettings.Instance.ConnectionString)) {
        // Open the connection
        ConnectionObject.Open();

        // Create command object
        using (SqlCommand CommandObject = new SqlCommand(sql, ConnectionObject)) {
          // Create a SQL Data Adapter
          using (SqlDataAdapter da = new SqlDataAdapter(CommandObject)) {
            // Fill DataTable using Data Adapter
            ret = new DataTable();
            da.Fill(ret);
          }
        }
      }

      return ret;
    }
    #endregion
  }
}
