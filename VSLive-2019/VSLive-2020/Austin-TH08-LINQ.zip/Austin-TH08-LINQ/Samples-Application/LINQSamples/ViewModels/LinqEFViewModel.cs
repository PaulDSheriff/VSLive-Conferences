﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class LinqEFViewModel : CommonBase
  {
    #region Properties
    private List<Product> _Products;

    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        Products = db.Products.ToList();
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region GetSpecificColumns
    public void GetSpecificColumns()
    {
      StringBuilder sb = new StringBuilder(1024);

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var products = (from prod in db.Products
                          select new ProductDTO
                          {
                            ProductID = prod.ProductID,
                            Name = prod.Name,
                            ProductNumber = prod.ProductNumber,
                            Size = prod.Size
                          }).ToList();

          foreach (var prod in products) {
            sb.AppendLine($"Product ID: {prod.ProductID}");
            sb.AppendLine($"    Name: {prod.Name}");
            sb.AppendLine($"    Number: {prod.ProductNumber}");
            sb.AppendLine($"    Size: {prod.Size}");
          }

          sb.AppendLine($"Total Products: {products.Count}");

          ResultText = sb.ToString();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var products = db.Products.Select(prod => new ProductDTO
          {
            ProductID = prod.ProductID,
            Name = prod.Name,
            ProductNumber = prod.ProductNumber,
            Size = prod.Size
          }).ToList();

          foreach (var prod in products) {
            sb.AppendLine($"Product ID: {prod.ProductID}");
            sb.AppendLine($"    Name: {prod.Name}");
            sb.AppendLine($"    Number: {prod.ProductNumber}");
            sb.AppendLine($"    Size: {prod.Size}");
          }

          sb.AppendLine($"Total Products: {products.Count}");

          ResultText = sb.ToString();
        }
      }

      Products = null;
    }
    #endregion

    #region Anonymous Class
    public void AnonymousClass()
    {
      StringBuilder sb = new StringBuilder(1024);

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var products = (from prod in db.Products
                          select new
                          {
                            ProductId = prod.ProductID,
                            ProductName = prod.Name,
                            Identifier = prod.ProductNumber,
                            ProductSize = prod.Size
                          });
          foreach (var prod in products) {
            sb.AppendLine($"ProductId: {prod.ProductId}");
            sb.AppendLine($"    ProductName: {prod.ProductName}");
            sb.AppendLine($"    Identifier: {prod.Identifier}");
            sb.AppendLine($"    ProductSize: {prod.ProductSize}");
          }
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var products = db.Products.Select(prod => new
          {
            ProductId = prod.ProductID,
            ProductName = prod.Name,
            Identifier = prod.ProductNumber,
            ProductSize = prod.Size
          });

          foreach (var prod in products) {
            sb.AppendLine($"ProductId: {prod.ProductId}");
            sb.AppendLine($"    ProductName: {prod.ProductName}");
            sb.AppendLine($"    Identifier: {prod.Identifier}");
            sb.AppendLine($"    ProductSize: {prod.ProductSize}");
          }
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region Distinct
    public void Distinct()
    {
      StringBuilder sb = new StringBuilder(1024);

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var colors = (from prod in db.Products
                        select prod.Color).Distinct().ToList();

          foreach (var color in colors) {
            sb.AppendLine($"Color: {color}");
          }

          sb.AppendLine($"Total Colors: {colors.Count}");

          ResultText = sb.ToString();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          var colors = db.Products.Select(prod => prod.Color).Distinct().ToList();

          foreach (var color in colors) {
            sb.AppendLine($"Color: {color}");
          }

          sb.AppendLine($"Total Colors: {colors.Count}");

          ResultText = sb.ToString();
        }
      }

      Products = null;
    }
    #endregion

    #region Join    
    public void Join()
    {
      StringBuilder sb = new StringBuilder(1024);
      List<SalesOrderDetail> Sales;

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        Products = db.Products.ToList();
        Sales = db.SalesOrderDetails.ToList();
      }

      var query = (from prod in Products
                   join so in Sales on prod.ProductID equals so.ProductID
                   select new
                   {
                     prod.ProductID,
                     ProductName = prod.Name,
                     prod.ProductNumber,
                     so.SalesOrderID,
                     so.OrderQty,
                     so.LineTotal
                   });

      foreach (var item in query) {
        sb.AppendLine($"Sales Order: {item.SalesOrderID}");
        sb.AppendLine($"  Product ID: {item.ProductID}");
        sb.AppendLine($"  Product Name: {item.ProductName}");
        sb.AppendLine($"  Product Number: {item.ProductNumber}");
        sb.AppendLine($"  Order Qty: {item.OrderQty}");
        sb.AppendLine($"  Total: {item.LineTotal.ToString("c")}");
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupBy
    public void GroupBy()
    {
      StringBuilder sb = new StringBuilder(1024);

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        var grouped = (from prod in db.Products
                       group prod by prod.Size into newProd
                       orderby newProd.Key
                       select newProd);

        foreach (var sizes in grouped) {
          sb.AppendLine($"Size: {sizes.Key}");
          foreach (var prod in sizes) {
            sb.Append($"  ProductID: {prod.ProductID}");
            sb.Append($"  Name: {prod.Name}");
            sb.AppendLine($"  Color: {prod.Color}");
          }
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region GroupedSubquery
    public void GroupedSubquery()
    {
      StringBuilder sb = new StringBuilder(1024);
      List<SalesOrderDetail> Sales;

      using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
        Products = db.Products.ToList();
        Sales = db.SalesOrderDetails.ToList();
      }

      // Get all products for a sales order id
      var query = (from sales in Sales
                   group sales by sales.SalesOrderID into newSale
                   select new
                   {
                     SalesOrderID = newSale.Key,
                     Products = (from prod in Products
                                 join so in Sales on prod.ProductID equals so.ProductID
                                 where so.SalesOrderID == newSale.Key
                                 select prod).ToList()
                   });

      foreach (var sales in query) {
        sb.AppendLine($"Sales ID: {sales.SalesOrderID}");
        foreach (var prod in sales.Products) {
          sb.Append($"  ProductID: {prod.ProductID}");
          sb.Append($"  Name: {prod.Name}");
          sb.AppendLine($"  Color: {prod.Color}");
        }
      }

      ResultText = sb.ToString();
      Products = null;
    }
    #endregion

    #region WhereClause Method
    public void WhereClause()
    {
      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = (from prod in db.Products
                      where prod.ProductID == 710
                      select prod).ToList();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = db.Products.Where(prod => prod.ProductID == 710).ToList();
        }
      }

      ResultText = string.Empty;
    }
    #endregion

    #region OrderBy Method
    public void OrderBy()
    {
      // Order By Product Name
      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = (from prod in db.Products
                      orderby prod.Name
                      select prod).ToList();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = db.Products.OrderBy(prod => prod.Name).ToList();
        }
      }

      ResultText = string.Empty;
    }
    #endregion

    #region OrderByDescending Method
    public void OrderByDescending()
    {
      // Order By Product Name
      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = (from prod in db.Products
                      orderby prod.Name descending
                      select prod).ToList();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = db.Products.OrderByDescending(prod => prod.Name).ToList();
        }
      }

      ResultText = string.Empty;
    }
    #endregion

    #region FirstOrDefault
    public void FirstOrDefault()
    {
      Product value;

      // NOTE: FirstOrDefault() returns a null if no value is found

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   where prod.Color == "Red"
                   select prod).FirstOrDefault();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.Where(prod => prod.Color == "Red").FirstOrDefault();
        }
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region LastOrDefault
    public void LastOrDefault()
    {
      Product value;

      // NOTE: LastOrDefault returns the last value in a collection, or null if no values are found
      // NOTE: LastOrDefault() only works after applying ToList()
      //       This means it is processed client-side

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   where prod.Color == "Red"
                   select prod).ToList().LastOrDefault();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.Where(prod => prod.Color == "Red").ToList().LastOrDefault();
        }
      }

      if (value == null) {
        ResultText = "Not Found";
      }
      else {
        ResultText = $"Found: {value.Name}";
      }
      Products = null;
    }
    #endregion

    #region Count
    public void Count()
    {
      int value;

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   select prod).Count();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.Count();
        }
      }

      ResultText = $"Total Products = {value}";
      Products = null;
    }
    #endregion

    #region Sum
    public void Sum()
    {
      decimal? value;

      if (UseQuerySyntax) {
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   select prod.ListPrice).Sum();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.Sum(prod => prod.ListPrice);
        }
      }

      ResultText = $"Total of all List Prices = {value.Value.ToString("c")}";
      Products = null;
    }
    #endregion

    #region All
    public void All()
    {
      bool value;

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   select prod).All(prod => prod.Name.Contains(" "));
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.All(prod => prod.Name.Contains(" "));
        }
      }

      ResultText = $"Do all Name properties contain a space? {value}";
      Products = null;
    }
    #endregion

    #region Any
    public void Any()
    {
      bool value;

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = (from prod in db.Products
                   select prod).Any(prod => prod.Name.Contains("z"));
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          value = db.Products.Any(prod => prod.Name.Contains("z"));
        }
      }

      ResultText = $"Do any Name properties contain an 'z'? {value}";
      Products = null;
    }
    #endregion

    #region SkipWhile Method
    public void SkipWhile()
    {
      // NOTE: SkipWhile() only works after applying ToList()
      //       This means it is processed client-side

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = (from prod in db.Products
                      orderby prod.Name
                      select prod).ToList().SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = db.Products.OrderBy(prod => prod.Name).ToList().SkipWhile(prod => prod.Name.StartsWith("A")).ToList();
        }
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion

    #region TakeWhile Method
    public void TakeWhile()
    {
      // NOTE: TakeWhile() only works after applying ToList()
      //       This means it is processed client-side

      if (UseQuerySyntax) {
        // Query Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = (from prod in db.Products
                      orderby prod.Name
                      select prod).ToList().TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
        }
      }
      else {
        // Method Syntax
        using (AdventureWorksLTDbContext db = new AdventureWorksLTDbContext()) {
          Products = db.Products.OrderBy(prod => prod.Name).ToList().TakeWhile(prod => prod.Name.StartsWith("A")).ToList();
        }
      }

      ResultText = $"Total Products: {Products.Count}";
    }
    #endregion
  }
}
