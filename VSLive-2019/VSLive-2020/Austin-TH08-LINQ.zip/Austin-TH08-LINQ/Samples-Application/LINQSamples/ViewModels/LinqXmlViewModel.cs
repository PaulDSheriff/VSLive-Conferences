﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Common.Library;

namespace LINQSamples.ViewModels
{
  public class LinqXmlViewModel : CommonBase
  {
    #region Properties
    private List<Product> _Products;

    public List<Product> Products
    {
      get { return _Products; }
      set {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region GetAll Method
    public void GetAll()
    {
      StringBuilder sb = new StringBuilder(1024);
      IEnumerable<XElement> products;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        products = (from prod in doc.Elements("Product")
                    select prod);
      }
      else {
        // Method Syntax
        products = doc.Elements("Product");
      }

      foreach (XElement prod in products) {
        sb.AppendLine(prod.Element("Name").Value);
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region WhereClause Method
    public void WhereClause()
    {
      StringBuilder sb = new StringBuilder(1024);
      IEnumerable<XElement> products;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        products = (from prod in doc.Elements("Product")
                    where prod.Element("ProductID").Value == "710"
                    select prod);
      }
      else {
        // Method Syntax
        products = doc.Elements("Product")
          .Where(prod => prod.Element("ProductID").Value == "710");
      }

      foreach (XElement prod in products) {
        sb.AppendLine(prod.Element("Name").Value);
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region WhereClauseUsingAttribute Method
    public void WhereClauseUsingAttribute()
    {
      XElement product;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsAttributesFile);

      if (UseQuerySyntax) {
        // Query Syntax
        product = (from prod in doc.Elements("Product")
                   where prod.Attribute("ProductID").Value == "716"
                   select prod).SingleOrDefault();
      }
      else {
        // Method Syntax
        product = doc.Elements("Product")
                 .Where(prod => prod.Attribute("ProductID").Value == "716")
                 .SingleOrDefault();
      }

      if (product != null) {
        ResultText = product.Attribute("Name").Value;
      }
      else {
        ResultText = "Not Found";
      }
    }
    #endregion

    #region OrderBy Method
    public void OrderBy()
    {
      StringBuilder sb = new StringBuilder(1024);
      IEnumerable<XElement> products;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      // Order By Product Name
      if (UseQuerySyntax) {
        // Query Syntax
        products = (from prod in doc.Elements("Product")
                    orderby prod.Element("Name").Value
                    select prod);
      }
      else {
        // Method Syntax
        products = doc.Elements("Product")
                   .OrderBy(prod => prod.Element("Name").Value);
      }

      foreach (var prod in products) {
        sb.Append(prod.Element("Name").Value);
        sb.Append(" - ");
        sb.AppendLine(prod.Element("ProductNumber").Value);
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region OrderByDescending Method
    public void OrderByDescending()
    {
      StringBuilder sb = new StringBuilder(1024);
      IEnumerable<XElement> products;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      // Order By Product Name
      if (UseQuerySyntax) {
        // Query Syntax
        products = (from prod in doc.Elements("Product")
                    orderby prod.Element("Name").Value descending
                    select prod);
      }
      else {
        // Method Syntax
        products = doc.Elements("Product")
                   .OrderBy(prod => prod.Element("Name").Value);
      }

      foreach (var prod in products) {
        sb.Append(prod.Element("Name").Value);
        sb.Append(" - ");
        sb.AppendLine(prod.Element("SellStartDate").GetAs<string>());
      }

      ResultText = sb.ToString();
    }
    #endregion

    #region Count Method
    public void Count()
    {
      int value;
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in doc.Elements("Product")
                 select prod).Count();
      }
      else {
        // Method Syntax
        value = doc.Elements("Product").Count();
      }

      ResultText = value.ToString();
    }
    #endregion

    #region Sum Method
    public void Sum()
    {
      decimal value;
      XElement doc = XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in doc.Elements("Product")
                 select prod.Element("ListPrice").GetAs<decimal>()).Sum();
      }
      else {
        // Method Syntax
        value = doc.Elements("Product")
                .Select(prod => prod.Element("ListPrice")
                .GetAs<decimal>()).Sum();
      }

      ResultText = value.ToString("c");
    }
    #endregion

    #region Minimum Method   
    public void Minimum()
    {
      decimal value;
      XElement doc = XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in doc.Elements("Product")
                 select prod.Element("ListPrice").GetAs<decimal>()).Min();
      }
      else {
        // Method Syntax
        value = doc.Elements("Product")
                .Select(prod => prod.Element("ListPrice")
                .GetAs<decimal>()).Min();
      }

      ResultText = value.ToString("c");
    }
    #endregion

    #region Maximum Method
    public void Maximum()
    {
      decimal value;
      XElement doc = XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in doc.Elements("Product")
                 select prod.Element("ListPrice").GetAs<decimal>()).Max();
      }
      else {
        // Method Syntax
        value = doc.Elements("Product")
                .Select(prod => prod.Element("ListPrice")
                .GetAs<decimal>()).Max();
      }

      ResultText = value.ToString("c");
    }
    #endregion

    #region Average Method
    public void Average()
    {
      decimal value;
      XElement doc = XElement.Load(AppSettings.Instance.ProductsFile);

      if (UseQuerySyntax) {
        // Query Syntax
        value = (from prod in doc.Elements("Product")
                 select prod.Element("ListPrice").GetAs<decimal>()).Average();
      }
      else {
        // Method Syntax
        value = doc.Elements("Product")
                .Select(prod => prod.Element("ListPrice")
                .GetAs<decimal>()).Average();
      }

      ResultText = value.ToString("c");
    }
    #endregion

    #region LoadClass Method
    public void LoadClass()
    {
      StringBuilder sb = new StringBuilder(1024);
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      ResultText = string.Empty;
      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in doc.Elements("Product")
                    select new Product
                    {
                      ProductID = prod.Element("ProductID").GetAs<int>(),
                      Name = prod.Element("Name").GetAs<string>(),
                      ProductNumber = prod.Element("ProductNumber").GetAs<string>(),
                      Color = prod.Element("Color").GetAs<string>(),
                      StandardCost = prod.Element("StandardCost").GetAs<decimal?>(),
                      ListPrice = prod.Element("ListPrice").GetAs<decimal?>(),
                      Size = prod.Element("Size").GetAs<string>(),
                      Weight = prod.Element("Weight").GetAs<decimal?>()
                    }).ToList();
      }
      else {
        // Method Syntax
        Products = doc.Elements("Product").Select(prod =>
           new Product
           {
             ProductID = prod.Element("ProductID").GetAs<int>(),
             Name = prod.Element("Name").GetAs<string>(),
             ProductNumber = prod.Element("ProductNumber").GetAs<string>(),
             Color = prod.Element("Color").GetAs<string>(),
             StandardCost = prod.Element("StandardCost").GetAs<decimal?>(),
             ListPrice = prod.Element("ListPrice").GetAs<decimal?>(),
             Size = prod.Element("Size").GetAs<string>(),
             Weight = prod.Element("Weight").GetAs<decimal?>()
           }).ToList();
      }
    }
    #endregion

    #region GetSpecificColumns
    public void GetSpecificColumns()
    {
      StringBuilder sb = new StringBuilder(1024);
      XElement doc =
            XElement.Load(AppSettings.Instance.ProductsFile);

      ResultText = string.Empty;
      if (UseQuerySyntax) {
        // Query Syntax
        Products = (from prod in doc.Elements("Product")
                    select new Product
                    {
                      ProductID = prod.Element("ProductID").GetAs<int>(),
                      Name = prod.Element("Name").GetAs<string>(),
                      ProductNumber = prod.Element("ProductNumber").GetAs<string>()
                    }).ToList();
      }
      else {
        // Method Syntax
        Products = doc.Elements("Product").Select(prod =>
           new Product
           {
             ProductID = prod.Element("ProductID").GetAs<int>(),
             Name = prod.Element("Name").GetAs<string>(),
             ProductNumber = prod.Element("ProductNumber").GetAs<string>()
           }).ToList();
      }
    }
    #endregion

    #region Join Method
    /// <summary>
    /// Join Products and prods, and create a new XML document with a different shape.
    /// </summary>
    public void Join()
    {
      XElement docProd;
      XElement docSales;

      // Load Products XML File
      docProd = XElement.Load(AppSettings.Instance.ProductsFile);
      // Load Sales Header XML File
      docSales = XElement.Load(AppSettings.Instance.SalesOrderDetailsFile);

      // Query Syntax
      // Create new XElement object that has new shape
      XElement newDoc =
        new XElement("SalesDetailWithProductInfo",
          from c in docProd.Elements("Product")
          join o in docSales.Elements("OrderDetail")
                    on (string)c.Element("ProductID") equals
                       (string)o.Element("ProductID")
          where c.Element("ProductID").Value == "987"
          select new XElement("Product",
              new XElement("ProductID", (string)c.Element("ProductID")),
              new XElement("Name", (string)c.Element("Name")),
              new XElement("ProductNumber", (string)c.Element("ProductNumber")),
              new XElement("SalesOrderID", (string)o.Element("SalesOrderID")),
              new XElement("OrderQty", (string)o.Element("OrderQty")),
              new XElement("UnitPrice", (decimal)o.Element("UnitPrice"))
          )
      );

      ResultText = newDoc.ToString();
    }
    #endregion

    #region ReadConfig Method
    public void ReadConfig()
    {
      StringBuilder sb = new StringBuilder(1024);
      IEnumerable<XElement> settings;
      XElement doc =
         XElement.Load(
           AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);

      if (UseQuerySyntax) {
        // Query Syntax
        // Find <appSettings> element and get all <add> elements
        settings = (from setting in doc.Elements("appSettings").Elements("add")
                    select setting);
      }
      else {
        // Method Syntax
        settings = doc.Elements("appSettings").Elements("add")
                   .Select(setting => setting);
      }

      if (settings != null) {
        foreach (var setting in settings) {
          sb.Append("key: '");
          sb.Append(setting.Attribute("key").Value);
          sb.Append("' - value: '");
          sb.AppendLine(setting.Attribute("value").Value + "'");
        }

        ResultText = sb.ToString();
      }
      else {
        ResultText = "Not Found";
      }
    }
    #endregion
  }
}