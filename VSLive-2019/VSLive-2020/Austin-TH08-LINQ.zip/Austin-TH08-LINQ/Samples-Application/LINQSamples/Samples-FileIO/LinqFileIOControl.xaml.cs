﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class LinqFileIOControl : UserControl
  {
    public LinqFileIOControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (LinqFileIOViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly LinqFileIOViewModel _viewModel = null;
    
    private void NewestFileButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetNewestFile();
    }

    private void TotalBytesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetTotalBytesInFolder();
    }

    private void SearchTextButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetTextInFile();
    }

    private void CompareFilesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.CompareTwoFolders();
    }

    private void CommonFilesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.CommonFilesInTwoFolders();
    }

    private void DifferentFilesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.DifferentFilesInTwoFolders();
    }
  }
}
