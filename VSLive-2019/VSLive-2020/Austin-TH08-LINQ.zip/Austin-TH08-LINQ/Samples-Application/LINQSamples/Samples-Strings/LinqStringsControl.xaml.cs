﻿using System.Windows;
using System.Windows.Controls;
using LINQSamples.ViewModels;

namespace LINQSamples
{
  public partial class LinqStringsControl : UserControl
  {
    public LinqStringsControl()
    {
      InitializeComponent();

      // Connect to instance of the view model created by the XAML
      _viewModel = (LinqStringViewModel)this.Resources["viewModel"];
    }

    // View model class
    private readonly LinqStringViewModel _viewModel = null;

    private void FindNumbersButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.FindNumbers();
    }

    private void TextBeforeButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.GetTextBefore();
    }

    private void FindSentencesButton_Click(object sender, RoutedEventArgs e)
    {
      _viewModel.FindSentences();
    }
  }
}
