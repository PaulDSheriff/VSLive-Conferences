﻿using System;
using System.Globalization;
using System.Xml.Linq;

namespace Common.Library
{
  public static class XmlHelper
  {
    public static T GetAs<T>(this XElement elem, T defaultValue = default)
    {
      T ret = defaultValue;
      // NOTE: Nullable.GetUnderlyingType only returns an object if T is a nullable type
      Type typ = Nullable.GetUnderlyingType(typeof(T));

      if (typ != null) {
        // Type is a Nullable<> type
        if (elem != null && !string.IsNullOrEmpty(elem.Value)) {
          var converter = System.ComponentModel.TypeDescriptor.GetConverter(typeof(T));
          if (converter.IsValid(elem.Value)) {
            ret = (T)converter.ConvertFromString(elem.Value);
          }
        }
      }
      else {
        if (elem != null && !string.IsNullOrEmpty(elem.Value)) {
          ret = (T)Convert.ChangeType(elem.Value, typeof(T), CultureInfo.InvariantCulture);
        }
      }

      return ret;
    }

    public static T GetAs<T>(this XAttribute attr, T defaultValue = default)
    {
      T ret = defaultValue;
      // NOTE: Nullable.GetUnderlyingType only returns an object if T is a nullable type
      Type typ = Nullable.GetUnderlyingType(typeof(T));

      if (typ != null) {
        // Type is a Nullable<> type
        if (attr != null && !string.IsNullOrEmpty(attr.Value)) {
          var converter = System.ComponentModel.TypeDescriptor.GetConverter(typeof(T));
          if (converter.IsValid(attr.Value)) {
            ret = (T)converter.ConvertFromString(attr.Value);
          }
        }
      }
      else {
        if (attr != null && !string.IsNullOrEmpty(attr.Value)) {
          ret = (T)Convert.ChangeType(attr.Value, typeof(T), CultureInfo.InvariantCulture);
        }
      }

      return ret;
    }
  }
}
