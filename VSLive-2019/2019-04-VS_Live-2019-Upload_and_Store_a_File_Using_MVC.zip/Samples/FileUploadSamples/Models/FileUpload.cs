using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FileUploadSamples.Models
{
  [Table("FileUpload")]
  public partial class FileUpload
  {
    [Key]
    public int FileUploadId { get; set; }

    [Required]
    [StringLength(100)]
    public string FileTitle { get; set; }

    [StringLength(500)]
    public string FileDescription { get; set; }

    [StringLength(500)]
    public string FilePath { get; set; }

    [StringLength(100)]
    public string FileName { get; set; }

    [StringLength(255)]
    public string ServerUrl { get; set; }

    [StringLength(255)]
    public string ServerThumbnailUrl { get; set; }

    public int? ContentLength { get; set; }

    [StringLength(100)]
    public string ContentType { get; set; }

    public byte[] Contents { get; set; }

    public object ContentsAsString
    {
      get {
        if (Contents != null) {
          return "data:" + ContentType + ";base64," + Convert.ToBase64String(Contents);
        }
        else {
          return null;
        }
      }
      set { var tmp = value; }
    }

    public byte[] Thumbnail { get; set; }

    public object ThumbnailAsString
    {
      get {
        if (Thumbnail != null) {
          return "data:" + ContentType + ";base64," + Convert.ToBase64String(Thumbnail);
        }
        else {
          return null;
        }
      }
      set { var tmp = value; }
    }
  }
}
