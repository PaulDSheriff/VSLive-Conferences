﻿using System.IO;
using System.Web;
using FileUploadSamples.Components;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class Thumbnail01ViewModel : ViewModelBase
  {
  }
}