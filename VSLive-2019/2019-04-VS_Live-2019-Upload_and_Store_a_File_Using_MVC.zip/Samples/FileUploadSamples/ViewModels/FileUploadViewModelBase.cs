﻿using System;
using System.Configuration;
using System.IO;
using System.Web;
using FileUploadSamples.Components;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class FileUploadViewModelBase : ViewModelBase
  {
    #region Constructor
    public FileUploadViewModelBase() : base()
    {
      // Get upload folder name from configuration file
      UploadFolderName = ConfigurationManager.AppSettings["uploadFolderName"];
      if (string.IsNullOrEmpty(UploadFolderName)) {
        // Set default folder name if not found
        UploadFolderName = "~/UploadedFiles/";
      }
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the name of the folder of where to store uploaded files
    /// </summary>
    public string UploadFolderName { get; set; }
    #endregion

    #region SetServerUrlProperties Method
    public void SetServerUrlProperties(FileUpload file)
    {
      string date;

      date = DateTime.Now.ToString("s").Replace(":", "-");

      file.ServerUrl = UploadFolderName + date + "-" + file.FileName;
      file.ServerThumbnailUrl = UploadFolderName + date + "-thumbnail-" + file.FileName;
    }
    #endregion
  }
}