﻿using System;
using System.IO;
using System.Web;

namespace FileUploadSamples.ViewModels
{
  public class VMSample01ViewModel
  {
    #region Public Properties
    public string FileTitle { get; set; }

    public string FileDescription { get; set; }

    public string FilePath { get; set; }

    public string FileName { get; set; }

    public int ContentLength { get; set; }

    public string ContentType { get; set; }

    public byte[] Contents { get; set; }

    public object ContentsAsString
    {
      get {
        if (Contents != null)
        {
          return "data:" + ContentType + ";base64," + Convert.ToBase64String(Contents);
        }
        else
        {
          return null;
        }
      }
      set { var tmp = value; }
    }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    public HttpPostedFileWrapper FileToUpload { get; set; }
    #endregion

    #region SetFileInfoProperties Method
    public void SetFileInfoProperties()
    {
      if (FileToUpload != null && FileToUpload.ContentLength > 0)
      {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream())
        {
          FileToUpload.InputStream.CopyTo(ms);
          ms.Position = 0;
          Contents = ms.ToArray();
        }

        // Fill in other file information
        ContentLength = FileToUpload.ContentLength;
        ContentType = FileToUpload.ContentType;
        FilePath = Path.GetDirectoryName(FileToUpload.FileName);
        FileName = Path.GetFileName(FileToUpload.FileName);
      }
    }
    #endregion
  }
}