﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class FileUploadViewModel : FileUploadViewModelBase
  {
    #region Constructor
    public FileUploadViewModel() : base()
    {
      Init();
    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the list of file uploads
    /// </summary>
    public List<FileUpload> FileUploadList { get; set; }
    #endregion

    #region Init Method
    public void Init()
    {
      FileUploadList = new List<FileUpload>();
    }
    #endregion

    #region LoadFileUploads Method
    public void LoadFileUploads()
    {
      FileUploadDB db = null;

      Init();

      using (db = new FileUploadDB()) {        
        FileUploadList = db.FileUploads.ToList();
      }
    }
    #endregion
    
    #region Load Method
    public void Load(int id)
    {
      FileUploadDB db = null;

      Init();

      using (db = new FileUploadDB()) {
        FileUploadInfo = db.FileUploads.Find(id);
      }
    }
    #endregion

    #region Save Method
    public bool Save()
    {
      bool ret = false;
      FileUploadDB db = null;

      try {
        // Create thumbnail
        CreateThumbnail();

        // Save file upload data
        using (db = new FileUploadDB()) {
          if (FileUploadInfo.FileUploadId == -1) {
            db.FileUploads.Add(FileUploadInfo);
          }
          else {
            db.Entry(FileUploadInfo).State = EntityState.Modified;
          }
          db.SaveChanges();
        }
        ret = true;
      }
      catch (DbEntityValidationException ex) {
        // TODO: Do something with Validation Errors
        Console.Write(ex.ToString());
      }
      catch(Exception ex) {
        Console.Write(ex.ToString());
      }

      return ret;
    }
    #endregion
  }
}