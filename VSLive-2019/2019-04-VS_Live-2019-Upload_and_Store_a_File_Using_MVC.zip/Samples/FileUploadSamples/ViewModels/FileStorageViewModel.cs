﻿using System;
using System.IO;
using System.Web;
using FileUploadSamples.Components;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class FileStorageViewModel : ViewModelBase
  {
    #region SetServerUrlProperties Method
    public void SetServerUrlProperties()
    {
      string date;

      date = DateTime.Now.ToString("s").Replace(":", "-");

      FileUploadInfo.ServerUrl = AppSettings.UploadFolderName + date + "-" + FileUploadInfo.FileName;
      FileUploadInfo.ServerThumbnailUrl = AppSettings.UploadFolderName + date + "-thumbnail-" + FileUploadInfo.FileName;
    }
    #endregion

    #region Save Method
    public void Save()
    {
      // Set file info properties from file upload control
      SetFileInfoProperties();

      // Create thumbnail
      CreateThumbnail();

      // Set Server URL properties
      SetServerUrlProperties();

      // Save on file system
      SaveToFileSystem();
    }
    #endregion

    #region SaveToFileSystem Method
    protected void SaveToFileSystem()
    {
      try {
        File.WriteAllBytes(HttpContext.Current.Server.MapPath(FileUploadInfo.ServerUrl), FileUploadInfo.Contents);
        File.WriteAllBytes(HttpContext.Current.Server.MapPath(FileUploadInfo.ServerThumbnailUrl), FileUploadInfo.Thumbnail);
      }
      catch (Exception ex) {
        System.Diagnostics.Debug.WriteLine(ex.ToString());
      }
    }
    #endregion
  }
}