﻿using System.Web.Mvc;

namespace FileUploadSamples.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }
  }
}