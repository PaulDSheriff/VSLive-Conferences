﻿using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class ThumbnailSamplesController : Controller
  {
    #region Sample 1
    public ActionResult Sample01()
    {
      Thumbnail01ViewModel vm = new Thumbnail01ViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample01(Thumbnail01ViewModel vm)
    {
      // Set file info properties from file upload control
      vm.SetFileInfoProperties();

      // Create thumbnail
      vm.CreateThumbnail();

      // Look at properties of View Model
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion
  }
}