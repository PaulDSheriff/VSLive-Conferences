﻿using System;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class SQLServerSamplesController : Controller
  {    
    #region Sample 1
    public ActionResult Sample01()
    {
      SQLServerViewModel vm = new SQLServerViewModel();

      return View(vm);
    }

    [HttpPost]
    public ActionResult Sample01(SQLServerViewModel vm)
    {
      // Store to SQL Server
      vm.Save();

      // Look in SQL Server for the new uploaded file
      System.Diagnostics.Debugger.Break();

      // TODO: Do something with the file data

      return View(vm);
    }
    #endregion
  }
}