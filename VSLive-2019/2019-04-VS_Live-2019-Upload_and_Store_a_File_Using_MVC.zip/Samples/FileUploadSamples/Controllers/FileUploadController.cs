﻿using System.Web.Mvc;
using FileUploadSamples.ViewModels;

namespace FileUploadSamples.Controllers
{
  public class FileUploadController : Controller
  {
    public ActionResult FileUploadList()
    {
      FileUploadViewModel vm = new FileUploadViewModel();

      vm.LoadFileUploads();

      return View(vm);
    }

    public ActionResult AddFile()
    {
      // Set 'id' to -1 to signify we are doing an "add"
      return RedirectToAction("FileUploadDetail", new { id = -1 });
    }

    public ActionResult FileUploadDetail(int id)
    {
      FileUploadViewModel vm = new FileUploadViewModel();

      vm.FileUploadInfo.FileUploadId = id;
      if (id != -1) {
        vm.Load(id);
      }

      return View(vm);
    }

    [HttpPost]
    public ActionResult FileUploadDetail(FileUploadViewModel vm)
    {
      ActionResult ret = View(vm);

      // Set file info properties from file upload control
      vm.SetFileInfoProperties();

      // Create thumbnail and save
      vm.Save();

      // Go back to list page
      ret = RedirectToAction("FileUploadList");

      return ret;
    }    
  }
}