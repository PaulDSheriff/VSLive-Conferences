﻿using System.IO;
using System.Web;
using System.Web.Mvc;

namespace FileUploadSamples.Controllers
{
  public class StyleSamplesController : Controller
  {
    #region Sample1
    public ActionResult Sample01()
    {
      return View();
    }

    [HttpPost]
    public ActionResult Sample01(HttpPostedFileWrapper fileToUpload)  // NOTE: the parameter name must match the 'id' in the HTML
    {
      // TODO: Do something with the posted file

      return View();
    }
    #endregion

    #region Sample 2
    public ActionResult Sample02()
    {
      return View();
    }

    [HttpPost]
    public ActionResult Sample02(HttpPostedFileWrapper fileToUpload)
    {
      // TODO: Do something with the posted file

      return View();
    }
    #endregion

    #region Sample 3
    public ActionResult Sample03()
    {
      return View();
    }

[HttpPost]
public ActionResult Sample03(HttpPostedFileWrapper fileToUpload)
{
  byte[] contents;

  if (fileToUpload != null && fileToUpload.ContentLength > 0) {
    // Get the uploaded file
    using (MemoryStream ms = new MemoryStream()) {
      fileToUpload.InputStream.CopyTo(ms);
      contents = ms.ToArray();
    }

    // Fill in other file information
    var fileInfo = new {
      fileToUpload.ContentLength,
      fileToUpload.ContentType,
      FilePath = Path.GetDirectoryName(fileToUpload.FileName),
      FileName = Path.GetFileName(fileToUpload.FileName),
      Contents = contents
    };

    // Look at all properties
    System.Diagnostics.Debugger.Break();

    // TODO: Do something with the file data
  }

  return View();
}
    #endregion
  }
}