﻿using System.IO;
using System.Web;
using FileUploadSamples.Components;
using FileUploadSamples.Models;

namespace FileUploadSamples.ViewModels
{
  public class ViewModelBase
  {
    #region Constructor
    public ViewModelBase()
    {
      FileUploadInfo = new FileUpload();

    }
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set file upload information
    /// </summary>
    public FileUpload FileUploadInfo { get; set; }

    /// <summary>
    /// Get/Set HTTP File Input Object
    /// </summary>
    public HttpPostedFileWrapper FileToUpload { get; set; }
    #endregion

    #region SetFileInfoProperties Method
    public void SetFileInfoProperties()
    {
      if (FileToUpload != null && FileToUpload.ContentLength > 0) {
        // Get the uploaded file
        using (MemoryStream ms = new MemoryStream()) {
          FileToUpload.InputStream.CopyTo(ms);
          ms.Position = 0;
          FileUploadInfo.Contents = ms.ToArray();
        }

        // Fill in other file information
        FileUploadInfo.ContentLength = FileToUpload.ContentLength;
        FileUploadInfo.ContentType = FileToUpload.ContentType;
        FileUploadInfo.FilePath = Path.GetDirectoryName(FileToUpload.FileName);
        FileUploadInfo.FileName = Path.GetFileName(FileToUpload.FileName);
      }
    }
    #endregion

    #region CreateThumbnail Method
    public void CreateThumbnail()
    {
      ImageThumbnailConverter conv = new ImageThumbnailConverter();

      // Create thumbnail
      FileUploadInfo.Thumbnail = conv.ConvertToThumbnail(FileUploadInfo.Contents, FileUploadInfo.ContentType);
    }
    #endregion
  }
}