﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace FileUploadSamples.Components
{
  public class ImageThumbnailConverter
  {
    #region CanConvertToThumbnail Method
    protected bool CanConvertToThumbnail(string type)
    {
      bool ret = false;

      // Get the file type
      if (type.Contains("/")) {
        type = type.Substring(type.LastIndexOf("/") + 1);
      }

      // See if the image type is in the list of valid types
      if (AppSettings.ImageTypes.Split(',').Contains(type)) {
        ret = true;
      }

      return ret;
    }
    #endregion

    #region ConvertToThumbnail Method
    public byte[] ConvertToThumbnail(byte[] image, string contentType)
    {      
      byte[] ret = null;

      if (CanConvertToThumbnail(contentType)) {
        // Resize image
        ret = Resize(image, AppSettings.ThumbWidth, AppSettings.ThumbHeight);
      }
      else {
        // Return 'No Preview' file
        ret = File.ReadAllBytes(AppSettings.NoPreviewFileName);
      }

      return ret;
    }
    #endregion

    #region Resize Method
    /// <summary>
    /// Resize a byte array of an image to the specified width and height
    /// </summary>
    /// <param name="image">The byte[] array to resize</param>
    /// <param name="width">The width to resize to</param>
    /// <param name="height">The height to resize to</param>
    /// <returns>A byte array of the resized image</returns>
    protected byte[] Resize(byte[] fullImage, int width, int height)
    {
      Image image = null;
      ImageConverter converter = new ImageConverter();
      Rectangle rect = new Rectangle(0, 0, width, height);
      Bitmap ret = new Bitmap(width, height);

      // Convert bytes to Image data type
      using (MemoryStream ms = new MemoryStream((byte[])fullImage)) {
        image = Image.FromStream(ms);
      }

      // Maintain DPI regardless of physical size
      ret.SetResolution(image.HorizontalResolution, image.VerticalResolution);

      // Create a new Graphics object from the Image
      // NOTE: Changes made to the graphic affect the Bitmap in the variable 'ret'
      using (Graphics newGraphic = Graphics.FromImage(ret)) {
        // Set high quality mode (may not be needed depending on image)
        newGraphic.CompositingMode = CompositingMode.SourceCopy;
        newGraphic.CompositingQuality = CompositingQuality.HighQuality;
        newGraphic.InterpolationMode = InterpolationMode.HighQualityBicubic;
        newGraphic.SmoothingMode = SmoothingMode.HighQuality;
        newGraphic.PixelOffsetMode = PixelOffsetMode.HighQuality;
        
        using (ImageAttributes imgAttr = new ImageAttributes()) {
          // Help prevent ghosting around the image 
          imgAttr.SetWrapMode(WrapMode.TileFlipXY);
          // Render the new Image
          newGraphic.DrawImage(image, rect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, imgAttr);
        }
      }

      // Convert new image to byte array and return it
      return (byte[])converter.ConvertTo(ret, typeof(byte[]));      
    }
    #endregion        
  }
}