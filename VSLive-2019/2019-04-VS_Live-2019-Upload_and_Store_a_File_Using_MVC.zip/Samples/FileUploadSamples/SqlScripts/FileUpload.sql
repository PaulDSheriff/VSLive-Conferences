﻿CREATE TABLE FileUpload(
	FileUploadId int IDENTITY(1,1) NOT NULL 
               CONSTRAINT PK_FileUpload PRIMARY KEY CLUSTERED,
	FileTitle nvarchar(100) NOT NULL,
	FileDescription nvarchar(500) NULL,
	FilePath nvarchar(255) NULL,
	FileName nvarchar(100) NULL,
	ContentLength int NULL,
	ContentType nvarchar(100) NULL,
	Contents varbinary(max) NULL,
	ServerUrl nvarchar(255) NULL,
	ServerThumbnailUrl nvarchar(255) NULL,
	Thumbnail varbinary(max) NULL
)