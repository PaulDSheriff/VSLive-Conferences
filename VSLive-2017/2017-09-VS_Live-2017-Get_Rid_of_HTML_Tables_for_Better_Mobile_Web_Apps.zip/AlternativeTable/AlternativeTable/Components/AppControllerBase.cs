﻿using System.Web;
using System.Web.Mvc;

namespace AlternativeTable
{
  public class AppControllerBase : Controller
  {
    #region SetAppSettings Method
    public void SetAppSettings(AppViewModelBase vm, HttpRequestBase request)
    {
      if (vm != null)
      {
        if (request != null)
        {
          vm.SetAppSettings(request.Browser.IsMobileDevice, request.UserAgent);
        }
      }
    }
    #endregion
  }
}