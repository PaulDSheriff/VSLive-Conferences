﻿using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class ProductController : AppControllerBase
  {
    public ActionResult Product()
    {
      TrainingProductViewModel vm = new TrainingProductViewModel();

      // Set Application Settings
      base.SetAppSettings(vm, Request);

      // Load Products into View Model
      vm.LoadProducts();

      return View(vm);
    }
  }
}