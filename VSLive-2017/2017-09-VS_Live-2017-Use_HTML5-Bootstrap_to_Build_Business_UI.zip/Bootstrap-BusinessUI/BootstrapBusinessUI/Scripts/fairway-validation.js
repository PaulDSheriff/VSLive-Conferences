﻿// **************************************************** //
// ** After HTML 5 required validation fires, locate ** //
// ** the first element in error, find the tab       ** //
// ** it is underthen make that tab the 'active' tab ** //
// **************************************************** //
function showTabInError()
{
if ($('input:invalid').length > 0) {
  // Get first invalid element
  var current = $('input:invalid').first()[0];
  // Find tab-pane in all parents
  var par = $(current).parents(".tab-pane")[0];
  // Find anchor tag that has the href of the 'id'
  $('a[href="#' + par.id + '"]').tab('show');
}
}

// ******************************************************* //
// ** Hook into our alert used for validation           ** //
// ** Don't use the data-dismiss="alert" because after  ** //
// ** the user closes it, you can't get it to redisplay ** //
// ******************************************************* //
$(function () {
  $('.close').click(function () {
    $('.alert').hide();
  });
});