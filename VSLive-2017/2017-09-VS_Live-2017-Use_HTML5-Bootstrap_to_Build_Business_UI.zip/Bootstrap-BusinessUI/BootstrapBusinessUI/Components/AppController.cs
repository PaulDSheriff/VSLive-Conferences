﻿using System.Data.Entity.Validation;
using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI
{
  public class AppController : Controller
  {
    protected void MoveValidationMessagesIntoModelState(EntityBase model)
    {
      // Add any additional validations into ModelState Dictionary
      if (model.ValidationMessages.Count > 0) {
        foreach (DbValidationError item in model.ValidationMessages) {
          ModelState.AddModelError(item.PropertyName, item.ErrorMessage);
        }
      }
    }
  }
}