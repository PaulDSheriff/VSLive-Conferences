﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;

namespace BootstrapBusinessUI
{
  public static class HtmlExtensions
  {
    #region Html5InputTypes Enumeration
    /// <summary>
    /// Enumerations for HTML 5 Input types
    /// </summary>
    public enum Html5InputTypes
    {
      /// <summary>
      /// HTML 5 input type=text
      /// </summary>
      text,
      /// <summary>
      /// HTML 5 input type=color
      /// </summary>
      color,
      /// <summary>
      /// HTML 5 input type=date
      /// </summary>
      date,
      /// <summary>
      /// HTML 5 input type=datetime
      /// </summary>
      datetime,
      /// <summary>
      /// HTML 5 input type=email
      /// </summary>
      email,
      /// <summary>
      /// HTML 5 input type=month
      /// </summary>
      month,
      /// <summary>
      /// HTML 5 input type=number
      /// </summary>
      number,
      /// <summary>
      /// HTML 5 input type=password
      /// </summary>
      password,
      /// <summary>
      /// HTML 5 input type=range
      /// </summary>
      range,
      /// <summary>
      /// HTML 5 input type=search
      /// </summary>
      search,
      /// <summary>
      /// HTML 5 input type=tel
      /// </summary>
      tel,
      /// <summary>
      /// HTML 5 input type=time
      /// </summary>
      time,
      /// <summary>
      /// HTML 5 input type=url
      /// </summary>
      url,
      /// <summary>
      /// HTML 5 input type=week
      /// </summary>
      week
    }
    #endregion

    #region Bootstrap Submit Button Helpers
    /// <summary>
    /// Bootstrap Submit Button Helper
    /// </summary>
    /// <param name="htmlHelper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input type='submit' with the appropriate properties set.</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper htmlHelper,
      string buttonText,
      object htmlAttributes = null)
    {
      return SubmitButton(htmlHelper, buttonText, null, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Submit Button Helper
    /// </summary>
    /// <param name="htmlHelper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input type='submit' with the appropriate properties set.</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper htmlHelper,
      string buttonText, string id,
      object htmlAttributes = null)
    {
      return SubmitButton(htmlHelper, buttonText, id, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Submit Button Helper
    /// </summary>
    /// <param name="htmlHelper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <param name="isDisabled">Set to true if you want the button disabled</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input type='submit' with the appropriate properties set.</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper htmlHelper,
      string buttonText, string id, bool isDisabled,
      object htmlAttributes = null)
    {
      return SubmitButton(htmlHelper, buttonText, id, isDisabled, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap Submit Button Helper
    /// </summary>
    /// <param name="htmlHelper">The helper</param>
    /// <param name="buttonText">The text for the button</param>
    /// <param name="id">The id for the button</param>
    /// <param name="isDisabled">Set to true if you want the button disabled</param>
    /// <param name="btnClass">The bootstrap 'btn-' class to use for this button</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input type='submit' with the appropriate properties set.</returns>
    public static MvcHtmlString SubmitButton(this HtmlHelper htmlHelper,
      string buttonText, string id, bool isDisabled, string btnClass,
      object htmlAttributes = null)
    {
      string html = string.Empty;
      string disable = string.Empty;

      if (string.IsNullOrEmpty(id))
        id = buttonText;
      if (string.IsNullOrEmpty(btnClass))
        btnClass = "btn-primary";

      // Ensure ID is a valid identifier
      id = id.Replace(" ", "").Replace("-", "_");

      html = "<input type='submit' class='btn {3}{1}' title='{0}' value='{0}' id='{2}' {4} />";
      if (isDisabled)
        disable = " disabled";

      html = string.Format(html, buttonText, disable,
                          id, btnClass,
                          GetHtmlAttributes(htmlAttributes));
      html = html.Replace("'", "\"");

      return new MvcHtmlString(html);
    }
    #endregion

    #region Bootstrap/HTML 5 Check Box Helpers
    /// <summary>
    /// Bootstrap and HTML 5 Check Box.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="htmlAttributes">Any additional HTML attributes</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString CheckBoxBootstrapFor<TModel>(
        this HtmlHelper<TModel> htmlHelper,
        Expression<Func<TModel, bool>> expression,
        string id,
        string text,
        object htmlAttributes = null)
    {
      return CheckBoxBootstrapFor(htmlHelper, expression, id, text, false, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Check Box in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this check box.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">The 'id' attribute name to set.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="isChecked">UNUSED: Whether or not to set the 'checked' attribute on this check box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this check box.</param>
    /// <param name="useInline">Whether or not to use 'checkbox-inline' for the Bootstrap class.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString CheckBoxBootstrapFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string text,
      bool isChecked,
      bool isAutoFocus,
      bool useInline = false,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      RouteValueDictionary rvd;

      rvd = new RouteValueDictionary(
        HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      //if (isChecked) {
      //   rvd.Add("checked", "checked");
      //}
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }

      // Build the CheckBox
      if (useInline) {
        sb.Append("<label class='checkbox-inline'>");
      }
      else {
        sb.Append("<div class='checkbox'>");
        sb.Append("  <label>");
      }

      // Build the CheckBox using InputExtensions class
      sb.Append(InputExtensions.CheckBoxFor(
        htmlHelper, expression, rvd));

      sb.Append(text);
      if (useInline) {
        sb.Append("</label>");
      }
      else {
        sb.Append("  </label>");
        sb.Append("</div>");
      }

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion

    #region Bootstrap/HTML 5 Check Box in a Button Helpers
    /// <summary>
    /// Bootstrap and HTML 5 Check Box in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this check box.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="htmlAttributes">Any additional HTML attributes</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString CheckBoxButtonFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string text,
      object htmlAttributes = null)
    {
      return CheckBoxButtonFor(htmlHelper, expression, id, text, null, false, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Check Box in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this check box.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box.</param>
    /// <param name="htmlAttributes">Any additional HTML attributes</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString CheckBoxButtonFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string text,
      string btnClass,
      object htmlAttributes = null)
    {
      return CheckBoxButtonFor(htmlHelper, expression, id, text, btnClass, false, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Check Box in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this check box.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="text">The text to display next to this check box.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box.</param>
    /// <param name="isChecked">Whether or not to set the 'checked' attribute on this check box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this check box.</param>
    /// <param name="useInline">Whether or not to use 'checkbox-inline' for the Bootstrap class.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML checkbox with the appropriate type set.</returns>
    public static MvcHtmlString CheckBoxButtonFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string text,
      string btnClass,
      bool isChecked,
      bool isAutoFocus,
      bool useInline = false,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      string chkClass = "checkbox";
      RouteValueDictionary rvd;

      rvd = new RouteValueDictionary(
        HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      if (string.IsNullOrEmpty(btnClass)) {
        btnClass = "btn-default";
      }
      //if (isChecked) {
      //   rvd.Add("checked", "checked");
      //}
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (useInline) {
        chkClass = "checkbox-inline";
      }

      // Build the CheckBox
      sb.AppendFormat("<div class='{0}'>", chkClass);
      sb.AppendFormat("  <label class='btn {0}'>", btnClass);

      // Build the CheckBox using InputExtensions class
      sb.Append(InputExtensions.CheckBoxFor(
        htmlHelper, expression, rvd));

      sb.AppendFormat("    {0}", text);
      sb.Append("  </label>");
      sb.Append("</div>");

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion

    #region Bootstrap/HTML 5 Radio Button
    /// <summary>
    /// Bootstrap and HTML 5 Radio Button.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="name">The 'name' attribute to set.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString RadioButtonBootstrapFor<TModel>(
          this HtmlHelper<TModel> htmlHelper,
          Expression<Func<TModel, bool>> expression,
          string id,
          string name,
          string text,
          string value,
          object htmlAttributes = null)
    {
      return RadioButtonBootstrapFor(htmlHelper, expression, id, name, text, value, false, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Radio Button in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this radio button.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="name">The 'name' attribute to set.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="isChecked">Whether or not to set the 'checked' attribute on this radio button.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this radio button.</param>
    /// <param name="useInline">Whether or not to use 'radio-inline' for the Bootstrap class.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString RadioButtonBootstrapFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string name,
      string text,
      string value,
      bool isChecked,
      bool isAutoFocus,
      bool useInline = false,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      string rdoClass = "radio";
      RouteValueDictionary rvd;

      rvd = new RouteValueDictionary(
        HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      //if (isChecked) {
      //   rvd.Add("checked", "checked");
      //}
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (useInline) {
        rdoClass = "radio-inline";
      }

      // Build the Radio Button
      sb.AppendFormat("<div class='{0}'>", rdoClass);
      sb.Append("  <label>");

      // Build the RadioButton using InputExtensions class
      sb.Append(InputExtensions.RadioButtonFor(
        htmlHelper, expression, rvd));

      sb.AppendFormat("    {0}", text);
      sb.Append("  </label>");
      sb.Append("</div>");

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion

    #region Bootstrap/HTML 5 Radio Button in a Button Helpers
    /// <summary>
    /// Bootstrap and HTML 5 Radio Button in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this radio button.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="name">The 'name' attribute to set.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString RadioButtonInButtonFor<TModel>(
          this HtmlHelper<TModel> htmlHelper,
          Expression<Func<TModel, bool>> expression,
          string id,
          string name,
          string text,
          string value,
          object htmlAttributes = null)
    {
      return RadioButtonInButtonFor(htmlHelper, expression, id, name, text, value, null, false, false, false, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Radio Button in a Button Helper.
    /// This helper assumes you have added the appropriate CSS to style this radio button.
    /// </summary>
    /// <typeparam name="TModel">The type of the Model</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="id">UNUSED: The 'id' attribute name to set.</param>
    /// <param name="name">The 'name' attribute to set.</param>
    /// <param name="text">The text to display next to this radio button.</param>
    /// <param name="value">The 'value' attribute to set.</param>
    /// <param name="btnClass">The Bootstrap 'btn-' class to add to this check box.</param>
    /// <param name="isChecked">Whether or not to set the 'checked' attribute on this radio button.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this radio button.</param>
    /// <param name="useInline">Whether or not to use 'radio-inline' for the Bootstrap class.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML radio button with the appropriate type set.</returns>
    public static MvcHtmlString RadioButtonInButtonFor<TModel>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, bool>> expression,
      string id,
      string name,
      string text,
      string value,
      string btnClass,
      bool isChecked,
      bool isAutoFocus,
      bool useInline = false,
      object htmlAttributes = null)
    {
      StringBuilder sb = new StringBuilder(512);
      string rdoClass = "radio";
      RouteValueDictionary rvd;

      rvd = new RouteValueDictionary(
        HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));

      if (string.IsNullOrEmpty(btnClass)) {
        btnClass = "btn-default";
      }
      //if (isChecked) {
      //   rvd.Add("checked", "checked");
      //}
      if (isAutoFocus) {
        rvd.Add("autofocus", "autofocus");
      }
      if (useInline) {
        rdoClass = "radio-inline";
      }

      // Build the Radio Button
      sb.AppendFormat("<div class='{0}'>", rdoClass);
      sb.AppendFormat("  <label class='btn {0}'>", btnClass);

      // Build the RadioButton using InputExtensions class
      sb.Append(InputExtensions.RadioButtonFor(
        htmlHelper, expression, rvd));

      sb.AppendFormat("    {0}", text);
      sb.Append("  </label>");
      sb.Append("</div>");

      // Return an MVC HTML String
      return MvcHtmlString.Create(sb.ToString());
    }
    #endregion

    #region Bootstrap/HTML 5 TextBox Helpers
    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The HTML helper type</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, Html5InputTypes.text, string.Empty, string.Empty, false, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="type">The text type to set (text, password, date, tel, email, etc.).</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, type, string.Empty, string.Empty, false, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, Html5InputTypes.text, title, title, false, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="type">The text type to set (text, password, date, tel, email, etc.).</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      string title,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, type, title, title, false, false, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="isRequired">Whether or not to set the 'required' attribute on this text box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this text box.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      string title,
      bool isRequired,
      bool isAutoFocus,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, Html5InputTypes.text, title, title, isRequired, isAutoFocus, null, htmlAttributes);
    }
    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="type">The text type to set (text, password, date, tel, email, etc.).</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="placeholder">The HTML 5 'placeholder' attribute to set.</param>
    /// <param name="isRequired">Whether or not to set the 'required' attribute on this text box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this text box.</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      string title,
      string placeholder,
      bool isRequired,
      bool isAutoFocus,
      object htmlAttributes = null)
    {
      return TextBoxBootstrapFor(htmlHelper, expression, type, title, placeholder, isRequired, isAutoFocus, null, htmlAttributes);
    }

    /// <summary>
    /// Bootstrap and HTML 5 Text Box Helper
    /// </summary>
    /// <typeparam name="TModel">The type of the model</typeparam>
    /// <typeparam name="TValue">The type of the value</typeparam>
    /// <param name="htmlHelper">The HTML helper instance that this method extends.</param>
    /// <param name="expression">An expression that identifies the object that contains the properties to render.</param>
    /// <param name="type">The text type to set (text, password, date, tel, email, etc.).</param>
    /// <param name="title">The HTML 5 'title' attribute to set.</param>
    /// <param name="placeholder">The HTML 5 'placeholder' attribute to set.</param>
    /// <param name="isRequired">Whether or not to set the 'required' attribute on this text box.</param>
    /// <param name="isAutoFocus">Whether or not to set the 'autofocus' attribute on this text box.</param>
    /// <param name="stringFormat">Any formatting to apply</param>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>An HTML input element with the appropriate type set.</returns>
    public static MvcHtmlString TextBoxBootstrapFor<TModel, TValue>(
      this HtmlHelper<TModel> htmlHelper,
      Expression<Func<TModel, TValue>> expression,
      Html5InputTypes type,
      string title,
      string placeholder,
      bool isRequired,
      bool isAutoFocus,
      string stringFormat,
      object htmlAttributes = null)
    {
      MvcHtmlString html = default(MvcHtmlString);
      Dictionary<string, object> attr = new Dictionary<string, object>();

      if (htmlAttributes != null) {
        var attributes =
          HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);
        foreach (var item in attributes) {
          attr.Add(item.Key, item.Value);
        }
      }

      attr.Add("type", type.ToString());
      attr.Add("class", "form-control");
      if (!string.IsNullOrEmpty(title)) {
        attr.Add("title", title);
      }
      if (!string.IsNullOrEmpty(placeholder)) {
        attr.Add("placeholder", placeholder);
      }
      if (isAutoFocus) {
        attr.Add("autofocus", "autofocus");
      }
      if (isRequired) {
        attr.Add("required", "required");
      }

      html = InputExtensions.TextBoxFor(htmlHelper,
                                        expression,
                                        stringFormat,
                                        attr);

      return html;
    }
    #endregion

    #region GetHtmlAttributes Method
    /// <summary>
    /// Break the HTML Attributes apart and put into key='value' pairs for adding to an HTML element.
    /// </summary>
    /// <param name="htmlAttributes">An object that contains the HTML attributes to set for the element.</param>
    /// <returns>A string with the key='value' pairs</returns>
    private static string GetHtmlAttributes(object htmlAttributes)
    {
      string ret = string.Empty;

      if (htmlAttributes != null) {
        var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);
        foreach (var item in attributes) {
          ret += " " + item.Key + "=" + "'" + item.Value + "'";
        }
      }

      return ret;
    }
    #endregion
  }
}