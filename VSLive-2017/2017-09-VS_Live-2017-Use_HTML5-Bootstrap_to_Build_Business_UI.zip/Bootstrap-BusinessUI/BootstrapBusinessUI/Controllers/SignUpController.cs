﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class SignUpController : AppController
  {
    public ActionResult SignUp1()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult SignUp1(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult SignUp2()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult SignUp2(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
  }
}