﻿using System.Web.Mvc;
using System.Collections.Generic;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class MemberProfileController : AppController
  {
    public ActionResult MemberProfile1()
    {
      MemberProfileViewModel vm = new MemberProfileViewModel();

      LoadViewModelCollections(vm);

      return View(vm);
    }
    
    [HttpPost]
    public ActionResult MemberProfile1(MemberProfileViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load Collections
      LoadViewModelCollections(vm);

      return View(vm);
    }
    
    public ActionResult MemberProfile2Inline()
    {
      MemberProfileViewModel vm = new MemberProfileViewModel();

      LoadViewModelCollections(vm);

      return View(vm);
    }

    [HttpPost]
    public ActionResult MemberProfile2Inline(MemberProfileViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load Collections
      LoadViewModelCollections(vm);

      return View(vm);
    }

    public ActionResult MemberProfile3Tabs()
    {
      MemberProfileViewModel vm = new MemberProfileViewModel();

      LoadViewModelCollections(vm);

      return View(vm);
    }

    [HttpPost]
    public ActionResult MemberProfile3Tabs(MemberProfileViewModel vm)
    {
      // Validate the model
      bool ret = vm.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(vm.Entity);
      }

      // Load Collections
      LoadViewModelCollections(vm);

      return View(vm);
    }
    
    private void LoadViewModelCollections(MemberProfileViewModel vm)
    {
      vm.LoadStates(Server.MapPath("~/Xml/USStates.xml"));
      vm.LoadQuestions(Server.MapPath("~/Xml/SecurityQuestions.xml"));
    }
  }
}