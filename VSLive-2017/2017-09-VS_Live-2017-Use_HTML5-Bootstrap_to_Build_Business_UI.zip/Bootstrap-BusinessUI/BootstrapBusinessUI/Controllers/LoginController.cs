﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class LoginController : AppController
  {
    public ActionResult Login1()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Login1(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
    
    public ActionResult Login2()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Login2(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult Login3()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Login3(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }


    public ActionResult Login4()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Login4(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult LoginModal()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult LoginModal(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
  }
}