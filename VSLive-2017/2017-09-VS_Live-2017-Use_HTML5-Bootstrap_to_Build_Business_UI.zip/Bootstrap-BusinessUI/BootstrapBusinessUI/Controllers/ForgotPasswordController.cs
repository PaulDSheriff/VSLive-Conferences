﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class ForgotPasswordController : AppController
  {
     public ActionResult ForgotPassword_NoHelper()
    {
      ForgotPasswordData model = new ForgotPasswordData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ForgotPassword_NoHelper(ForgotPasswordData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
    
    public ActionResult ForgotPassword1()
    {
      ForgotPasswordData model = new ForgotPasswordData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ForgotPassword1(ForgotPasswordData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult ForgotPassword2()
    {
      ForgotPasswordData model = new ForgotPasswordData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ForgotPassword2(ForgotPasswordData model)
    {
      // Validate the model
      model.IsSecurityAnswerRequired = true;
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }

    public ActionResult ChangePassword1()
    {
      ChangePasswordData model = new ChangePasswordData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult ChangePassword1(ChangePasswordData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }
  }
}