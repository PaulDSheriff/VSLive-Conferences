﻿using System.Web.Mvc;
using SamplesData;

namespace BootstrapBusinessUI.Controllers
{
  public class WizardController : AppController
  {
    public ActionResult Wizard()
    {
      UserData model = new UserData();

      model.Email = "psheriff@fairwaytech.com";

      return View(model);
    }

    [HttpPost]
    public ActionResult Wizard(UserData model)
    {
      // Validate the model
      bool ret = model.Validate();

      if (ret) {
        return RedirectToAction("Index", "Home");
      }
      else {
        // Add any additional validations into ModelState Dictionary
        MoveValidationMessagesIntoModelState(model);
      }

      return View(model);
    }    
  }
}