﻿using System.Collections.Generic;

namespace SamplesData
{
  public class CreditCardType
  {
    #region Public Properties
    public string Value { get; set; }
    public string Name { get; set; }
    public int SecurityCodeLength { get; set; }
    #endregion
  }
}
