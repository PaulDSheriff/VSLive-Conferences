﻿using System;
using System.ComponentModel.DataAnnotations;

namespace SamplesData
{
  public class ChangePasswordData : EntityBase
  {
    #region Init Method
    public override void Init()
    {
      base.Init();

      Email = string.Empty;
      Password = string.Empty;
      NewPassword = string.Empty;
      ConfirmPassword = string.Empty;
    }
    #endregion

    #region Public Properties
    public string Email { get; set; }
    public string Password { get; set; }
    public string NewPassword { get; set; }
    public string ConfirmPassword { get; set; }
    #endregion

    #region Validate Method
    public override bool Validate()
    {
      // New password must be different than old password
      if (Password == NewPassword) {
        AddModelError("NewPassword", "New Password must be different from Old Password.");
      }

      // New password and confirm password must be the same
      if (NewPassword != ConfirmPassword) {
        AddModelError("NewPassword", "New Password and Confirm Password must be the same.");
      }

      return IsValid;
    }
    #endregion
  }
}
