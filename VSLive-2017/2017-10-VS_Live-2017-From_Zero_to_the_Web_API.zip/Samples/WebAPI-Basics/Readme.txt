﻿Samples for Web API
-----------------------------------
Sample01 - Basic template controller

Sample02 - GET products from database
Sample03 - GET(id) a single product
Sample04 - Custom routing - Look in WebApiConfig class
Sample05 - Convert to camel case - Look in Global.asax 
           No Controller for this sample, just use the previous controller.
Sample06 - Query string parameters

Sample07 - POST
Sample08 - PUT
Sample09 - DELETE

Sample10 - IHttpActionResult for GET
Sample11 - IHttpActionResult for GET(id)
Sample12 - IHttpActionResult for POST
Sample13 - IHttpActionResult for PUT
Sample14 - IHttpActionResult for DELETE