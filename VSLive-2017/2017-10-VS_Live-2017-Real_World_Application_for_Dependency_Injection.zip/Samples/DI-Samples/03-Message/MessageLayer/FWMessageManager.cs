﻿namespace FW.MessageLayer
{
  /// <summary>
  /// "Dependent" for reading .Config files
  /// </summary>
  public class FWMessageManager
  {
    #region Constructors
    public FWMessageManager()
    {
    }

    public FWMessageManager(FWMessageBase reader)
    {
      _MessageReader = reader;
    }
    #endregion

    #region Instance
    private static FWMessageManager _Instance = null;

    public static FWMessageManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new FWMessageManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Message Reader Property
    private FWMessageBase _MessageReader = null;

    public FWMessageBase MessageReader
    {
      get { return _MessageReader; }
      set { _MessageReader = value; }
    }
    #endregion

    #region GetMessage Methods
    public virtual string GetMessage(string key)
    {
      if (MessageReader == null)
        return string.Empty;
      else
        return MessageReader.GetMessage(key);
    }

    public virtual string GetMessage(string key, string defaultValue)
    {
      if (MessageReader == null)
        return defaultValue;
      else
        return MessageReader.GetMessage(key, defaultValue);
    }
    #endregion
  }
}
