﻿using System;

namespace FW.MessageLayer
{
  /// <summary>
  /// Base class for all "Injector" classes
  /// </summary>
  public abstract class FWMessageBase
  {
    #region Constructors
    public FWMessageBase()
    {
      Location = string.Empty;
    }

    public FWMessageBase(string location)
    {
      Location = location;
    }
    #endregion

    public string Location { get; set; }

    public virtual string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Message {0} Not Found.", key));
    }

    public abstract string GetMessage(string key, string defaultMessage);
  }
}
