﻿using System.Linq;
using System.Xml.Linq;

namespace FW.MessageLayer
{
  /// <summary>
  /// "Injector" class for reading from XML files
  /// </summary>
  public class FWMessageXml : FWMessageBase
  {
    #region Constructors
    public FWMessageXml()
      : base()
    {
    }

    public FWMessageXml(string location)
      : base(location)
    {
    }
    #endregion

    public override string GetMessage(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      XElement doc = XElement.Load(Location);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;

      return ret;
    }
  }
}
