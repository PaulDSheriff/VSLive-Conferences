﻿namespace FW.MessageLayer
{
  public interface IFWMessageReader
  {
    string Location { get; set; }

    string GetMessage(string key);
    string GetMessage(string key, string defaultMessage);
  }
}
