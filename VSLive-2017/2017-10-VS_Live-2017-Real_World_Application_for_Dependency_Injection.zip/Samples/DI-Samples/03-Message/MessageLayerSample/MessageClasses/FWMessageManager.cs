﻿using System;

namespace FW.MessageLayer
{
  /// <summary>
  /// "Dependent" for reading .Config files
  /// </summary>
  public class FWMessageManager
  {
    public FWMessageManager(IFWMessageReader reader)
    {
      if (reader == null) {
        throw new ArgumentNullException("reader");
      }

      _MessageReader = reader;
    }

    private IFWMessageReader _MessageReader = null;

    public virtual string GetMessage(string key)
    {
      return _MessageReader.GetMessage(key);
    }

    public virtual string GetMessage(string key, string defaultValue)
    {
      return _MessageReader.GetMessage(key, defaultValue);
    }
  }
}
