﻿using System.Windows;
using FW.Common;
using FW.MessageLayer;

namespace MessageLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnGetMessage_Click(object sender, RoutedEventArgs e)
    {
      FWMessageManager mgr = new FWMessageManager(
        new FWMessageXml(FWFileCommon.GetCurrentDirectory() + @"\xml\Messages.xml"));

      txtValue.Text = mgr.GetMessage(txtKey.Text);
    }

    private void btnGetMessageDefault_Click(object sender, RoutedEventArgs e)
    {
      FWMessageManager mgr = new FWMessageManager(
        new FWMessageXml(FWFileCommon.GetCurrentDirectory() + @"\xml\Messages.xml"));

      txtValue.Text = mgr.GetMessage(txtKey.Text, txtDefault.Text);
    }
  }
}
