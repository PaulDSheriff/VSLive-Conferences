﻿using System.Diagnostics;
using System.Windows;
using FW.ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
    
    private void btnGetSettingInstance_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = 
        new FWConfigurationManager(new FWConfigurationConfig());

      txtValue.Text = mgr.GetSetting(txtKey.Text);
    }

    private void btnGetSetting_Click(object sender, RoutedEventArgs e)
    {
      // See the code in ApplicationStart.cs to see the initialization
      txtValue.Text = FWConfigurationManager.Instance.GetSetting(txtKey.Text);
    }

    private void btnGetSettingDefault_Click(object sender, RoutedEventArgs e)
    {
      txtValue.Text = FWConfigurationManager.Instance.GetSetting(txtKey.Text, txtDefault.Text);
    }

    private void btnAppConfig_Click(object sender, RoutedEventArgs e)
    {
      // See the code in AppConfig.cs to see the implementation of this
      Debug.WriteLine(AppConfig.Instance.EmpType);
      Debug.WriteLine(AppConfig.Instance.DefaultStateCode);

      Debugger.Break();
    }
  }
}
