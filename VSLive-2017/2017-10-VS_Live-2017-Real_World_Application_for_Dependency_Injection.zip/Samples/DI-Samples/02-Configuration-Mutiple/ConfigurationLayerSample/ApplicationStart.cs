﻿using FW.Common;
using FW.ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Configuration Manager
      InitializeConfigurationManager();
    }

    protected void InitializeConfigurationManager()
    {
      //**************************************************************
      // Create Configuration Manager and use the Xml Provider
      //**************************************************************
      //FWConfigurationManager.Instance =
      //  new FWConfigurationManager(
      //    new FWConfigurationXml(
      //      FWFileCommon.GetCurrentDirectory() + @"\Settings.xml"));

      //**************************************************************
      // Create Configuration Manager and use the Registry Provider
      //**************************************************************
      //FWConfigurationManager.Instance =
      // new FWConfigurationManager(
      //  new FWConfigurationRegistry(@"Software\MyApp"));

      //*********************************************************************
      // Create Configuration Manager and use the Configuration File Provider
      //*********************************************************************
      FWConfigurationManager.Instance =
       new FWConfigurationManager(
         new FWConfigurationConfig());
    }
  }
}
