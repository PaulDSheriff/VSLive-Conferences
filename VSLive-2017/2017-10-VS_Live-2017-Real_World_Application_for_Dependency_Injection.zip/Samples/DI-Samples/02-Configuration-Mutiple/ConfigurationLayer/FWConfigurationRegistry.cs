using Microsoft.Win32;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading Registry
  /// </summary>
  public class FWConfigurationRegistry : FWConfigurationBase
  {
    #region Constructors  
    public FWConfigurationRegistry(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      RegistryKey rk = null;
      string ret = defaultValue;

      // Open Registry Key
      rk = Registry.CurrentUser.OpenSubKey(base.Location, true);

      // Did we find the registry entry?
      if (rk == null)
      {
        ret = defaultValue;
      }
      else {
        ret = rk.GetValue(key, defaultValue).ToString();
        rk.Close();
        rk.Dispose();
      }

      return ret;
    }
    #endregion
  }
}