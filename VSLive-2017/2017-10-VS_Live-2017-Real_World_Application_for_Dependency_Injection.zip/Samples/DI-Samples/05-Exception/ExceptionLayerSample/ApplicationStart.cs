﻿using FW.ExceptionLayer;
using ExceptionLayerSample.Common;

namespace ExceptionLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    protected void InitializeExceptionManager()
    {
      //**************************************************************
      // Create Exception Manager and Add 'File' Publisher
      //**************************************************************
      FWExceptionManager.Instance.Publishers.Add(
        new FWExceptionToFile(FWFileCommon.GetCurrentDirectory() + 
                                 @"\Exceptions.txt"));

      //**************************************************************
      // Create Exception Manager and Add 'Database' Publisher
      //**************************************************************
      FWExceptionManager.Instance.Publishers.Add(
        new FWExceptionToDB("Server=Localhost;Database=Sandbox;Integrated Security=Yes"));

      //**************************************************************
      // Create Exception Manager and Add 'Email' Publisher
      //**************************************************************
      //FWEmailSettings settings = new FWEmailSettings();
      //settings.FromEmail = "PSheriff@fairwaytech.com";
      //settings.ToEmail = "PSheriff@fairwaytech.com";
      //settings.Subject = "Exception from the Exception Layer Samples";
      //FWExceptionManager.Instance.Publishers.Add(
      //  new FWExceptionToEMail(settings));
    }
  }
}
