﻿using System;
using System.Collections.Specialized;
using System.Windows;

using FW.ExceptionLayer;

namespace ExceptionLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnPublish_Click(object sender, RoutedEventArgs e)
    {
      FWExceptionManager.Instance.Publish(
        new ApplicationException("This is an exception"));

      MessageBox.Show("Exception Published");
    }

    private void btnPublishWithExtras_Click(object sender, RoutedEventArgs e)
    {
      NameValueCollection nvc = new NameValueCollection();
      nvc.Add("DefaultStateCode", "CA");
      nvc.Add("EmpType", "20");

      FWExceptionManager.Instance.Publish(
        new ApplicationException("This is an exception"), nvc);

      MessageBox.Show("Exception Published");
    }
  }
}
