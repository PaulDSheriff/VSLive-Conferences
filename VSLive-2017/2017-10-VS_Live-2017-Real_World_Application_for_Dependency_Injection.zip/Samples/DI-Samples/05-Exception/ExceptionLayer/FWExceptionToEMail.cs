using System;
using System.Net.Mail;

namespace FW.ExceptionLayer
{
  /// <summary>
  /// "Injector" class for publishing to email
  /// </summary>
  public class FWExceptionToEMail : FWExceptionPublisherBase
  {
    #region Constructors
    /// <summary>
    /// Create an instance of an email exception publisher
    /// </summary>
    /// <param name="settings">An instance of FWEmailSettings</param>
    public FWExceptionToEMail(FWEmailSettings settings)
    {
      _Settings = settings;
    }
    #endregion

    #region Private Properties
    private FWEmailSettings _Settings = null;
    #endregion

    #region PublishSpecial Method
    protected override void PublishSpecial()
    {
      SmtpClient smtp = null;

      _Settings.ToEmail = _Settings.ToEmail.Replace(";", ",");
      try
      {
        smtp = new SmtpClient();

        // TODO: Uncomment out the following when you are hooked up to email
        //  Send Exception via Email
        //smtp.Send(_Settings.FromEmail,
        //          _Settings.ToEmail,
        //          _Settings.Subject,
        //          ExceptionInfo.ToString());
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in FWExceptionToEmail publisher.", ex);
      }
      finally
      {
        if (smtp != null)
        {
          smtp.Dispose();
        }
      }
    }
    #endregion
  }
}