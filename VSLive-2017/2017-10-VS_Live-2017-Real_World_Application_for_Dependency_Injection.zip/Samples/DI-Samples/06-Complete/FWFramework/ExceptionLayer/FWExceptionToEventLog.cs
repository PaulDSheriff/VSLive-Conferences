using System;
using System.Diagnostics;

namespace FW.ExceptionLayer
{
  /// <summary>
  /// "Injector" class for publishing to email
  /// </summary>
  public class FWExceptionToEventLog : FWExceptionPublisherBase
  {
    #region Constructors
    public FWExceptionToEventLog(string logName)
      : base()
    {
      _LogName = logName;
      Init();
    }

    public FWExceptionToEventLog(string logName, bool isActive)
      : base()
    {
      _LogName = logName;
      Init();
    }
    #endregion

    #region Init Method
    protected void Init()
    {
      if (string.IsNullOrEmpty(_LogName))
      {
        _LogName = "Application";
      }
    }
    #endregion

    #region Private Variables
    private string _LogName = "Application";
    #endregion

    #region PublishSpecial Method
    protected override void PublishSpecial()
    {
      EventLog el = null;

      try
      {
        //  Write to EventLog Here
        el = new EventLog();

        // Set Application name as the Event Source
        el.Source = _LogName;

        el.WriteEntry(ExceptionInfo.ToString(), EventLogEntryType.Error);
      }
      catch (Exception ex)
      {
        throw new ApplicationException("Error in FWExceptionToEventLog", ex);
      }
    }
    #endregion
  }
}