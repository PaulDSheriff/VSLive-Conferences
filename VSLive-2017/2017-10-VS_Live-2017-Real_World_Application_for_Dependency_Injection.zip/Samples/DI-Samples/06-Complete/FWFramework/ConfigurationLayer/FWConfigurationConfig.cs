using System.Configuration;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading from .Config file
  /// </summary>
  public class FWConfigurationConfig : FWConfigurationBase
  {
    #region Constructor
    public FWConfigurationConfig(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      string ret;

      ret = ConfigurationManager.AppSettings[key];
      if (ret == null)
        ret = defaultValue;

      return ret;
    }
    #endregion
  }
}