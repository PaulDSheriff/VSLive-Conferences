using System.Xml;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading from XML file
  /// </summary>
  public class FWConfigurationXml : FWConfigurationBase
  {
    #region Constructors
    public FWConfigurationXml(string location)
      : base(location)
    {
    }
    #endregion

    #region GetSetting Method
    public override string GetSetting(string key, string defaultValue)
    {
      XmlDocument xd = null;
      XmlNode xn = null;
      string xPathQuery = null;
      string ret = defaultValue;

      xd = new XmlDocument();
      xd.Load(base.Location);

      xPathQuery = string.Format("/configuration/appSettings/add[@key='{0}']", key);

      xn = xd.SelectSingleNode(xPathQuery);

      if (xn != null)
      {
        ret = xn.Attributes["value"].Value;
      }

      return ret;
    }
    #endregion
  }
}