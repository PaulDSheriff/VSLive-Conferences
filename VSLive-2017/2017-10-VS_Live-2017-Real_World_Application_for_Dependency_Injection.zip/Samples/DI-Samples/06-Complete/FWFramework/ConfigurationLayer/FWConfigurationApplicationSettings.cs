﻿using FW.Common;
using System;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// This class reads all of the standard FW settings for any application
  /// </summary>
  public class FWConfigurationApplicationSettings
  {
    #region Constructor
    public FWConfigurationApplicationSettings()
      : base()
    {
      Init();
    }
    #endregion

    #region Init Method
    public virtual void Init()
    {
      UseExceptionFilePublisher = false;
      UseExceptionEventLogPublisher = true;
      UseExceptionEmailPublisher = false;
      UseExceptionTablePublisher = false;
      ExceptionFileName = @"[AppPath]\Exception.log";
      ExceptionEventLog = "Application";
      ExceptionEmailFromDisplayName = string.Empty;
      ExceptionEmailFrom = string.Empty;
      ExceptionEmailTo = string.Empty;
      ExceptionEmailSubject = string.Empty;
    }
    #endregion

    #region Standard Public Properties
    /// <summary>
    /// Get/Set the location of the global configuration settings for this application
    /// </summary>
    public string ConfigurationSource { get; set; }
    /// <summary>
    /// Get/Set the file location of the configuration settings for this application
    /// </summary>
    public string ConfigurationLocation { get; set; }

    /// <summary>
    /// Get/Set the location of the messages for this application
    /// </summary>
    public string MessageSource { get; set; }
    /// <summary>
    /// Get/Set the file location of the messages for this application
    /// </summary>
    public string MessageLocation { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the File Exception Publisher
    /// </summary>
    public bool UseExceptionFilePublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Event Log Exception Publisher
    /// </summary>
    public bool UseExceptionEventLogPublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Email Exception Publisher
    /// </summary>
    public bool UseExceptionEmailPublisher { get; set; }

    /// <summary>
    /// Get/Set whether or not to use the Table Exception Publisher
    /// </summary>
    public bool UseExceptionTablePublisher { get; set; }

    /// <summary>
    /// Get/Set the file name to write exceptions to
    /// </summary>
    public string ExceptionFileName { get; set; }

    /// <summary>
    /// Get/Set the log to write exceptions to
    /// </summary>
    public string ExceptionEventLog { get; set; }

    /// <summary>
    /// Get/Set the connection string to write exceptions to
    /// </summary>
    public string ExceptionConnectionString { get; set; }

    /// <summary>
    /// Get/Set Display name for emailing exception
    /// </summary>
    public string ExceptionEmailFromDisplayName { get; set; }

    /// <summary>
    /// Get/Set ToEmail
    /// </summary>
    public string ExceptionEmailTo { get; set; }

    /// <summary>
    /// Get/Set the email from address
    /// </summary>
    public string ExceptionEmailFrom { get; set; }

    /// <summary>
    /// Get/Set Subject
    /// </summary>
    public string ExceptionEmailSubject { get; set; }
    #endregion

    #region Standard Settings Load Method
    public virtual void LoadStandardSettings()
    {
      // Use Configuration Reader
      FWConfigurationManager.Instance = 
        new FWConfigurationManager(new FWConfigurationConfig(string.Empty));

      // Exception Manager Information
      UseExceptionFilePublisher = Convert.ToBoolean(FWConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionFilePublisher"));
      UseExceptionEventLogPublisher = Convert.ToBoolean(FWConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionEventLogPublisher"));
      UseExceptionEmailPublisher = Convert.ToBoolean(FWConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionEmailPublisher"));
      UseExceptionTablePublisher = Convert.ToBoolean(FWConfigurationManager.Instance.ConfigurationReader.GetSetting("UseExceptionTablePublisher"));

      ExceptionFileName = FWString.ExpandSpecialFolders(FWConfigurationManager.Instance.GetSetting("ExceptionFileName"));
      ExceptionEmailFromDisplayName = FWConfigurationManager.Instance.GetSetting("ExceptionEmailFromDisplayName");
      ExceptionEmailTo = FWConfigurationManager.Instance.GetSetting("ExceptionEmailTo");
      ExceptionEmailFrom = FWConfigurationManager.Instance.GetSetting("ExceptionEmailFrom");
      ExceptionEmailSubject = FWConfigurationManager.Instance.GetSetting("ExceptionEmailSubject");
      ExceptionEventLog = FWConfigurationManager.Instance.GetSetting("ExceptionEventLog");
      ExceptionConnectionString = FWConfigurationManager.Instance.GetSetting("ExceptionConnectionString");

      ConfigurationSource = FWConfigurationManager.Instance.GetSetting("ConfigurationSource");
      ConfigurationLocation = FWString.ExpandSpecialFolders(FWConfigurationManager.Instance.GetSetting("ConfigurationLocation"));

      MessageSource = FWConfigurationManager.Instance.GetSetting("MessageSource");
      MessageLocation = FWString.ExpandSpecialFolders(FWConfigurationManager.Instance.GetSetting("MessageLocation"));
    }
    #endregion
  }
}
