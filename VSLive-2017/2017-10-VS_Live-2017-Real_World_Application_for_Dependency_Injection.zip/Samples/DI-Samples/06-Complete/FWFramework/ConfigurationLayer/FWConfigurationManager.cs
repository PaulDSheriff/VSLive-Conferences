namespace FW.ConfigurationLayer
{
  /// <summary>
  /// "Dependent" class
  /// </summary>
  public class FWConfigurationManager
  {
    #region Constructors
    public FWConfigurationManager()
    {
    }

    public FWConfigurationManager(FWConfigurationBase reader)
    {
      _ConfigReader = reader;
    }
    #endregion

    #region Instance
    private static FWConfigurationManager _Instance = null;

    public static FWConfigurationManager Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new FWConfigurationManager();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    #region Configuration Reader Property
    private FWConfigurationBase _ConfigReader = null;

    public FWConfigurationBase ConfigurationReader
    {
      get { return _ConfigReader; }
      set { _ConfigReader = value; }
    }
    #endregion

    #region GetSetting Methods
    public virtual string GetSetting(string key)
    {
      if (ConfigurationReader == null)
        return string.Empty;
      else
        return ConfigurationReader.GetSetting(key);
    }

    public virtual string GetSetting(string key, string defaultValue)
    {
      if (ConfigurationReader == null)
        return defaultValue;
      else
        return ConfigurationReader.GetSetting(key, defaultValue);
    }
    #endregion
  }
}