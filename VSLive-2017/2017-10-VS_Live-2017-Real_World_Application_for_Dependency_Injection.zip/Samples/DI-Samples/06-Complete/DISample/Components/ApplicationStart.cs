﻿using FW.Common;
using FW.ConfigurationLayer;
using FW.ExceptionLayer;
using FW.MessageLayer;

namespace DISample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    // Class to read standard framework settings
    private FWConfigurationApplicationSettings _Settings = new FWConfigurationApplicationSettings();

    public void Initialize()
    {
      // Load all Configuration Settings from Web.Config
      _Settings.LoadStandardSettings();

      // Initialize Configuration Manager
      InitializeConfigurationManager();

      // Initialize Message Manager
      InitializeMessageManager();

      // Initialize Exception Manager
      InitializeExceptionManager();
    }

    #region InitializeConfigurationManager Method
    protected void InitializeConfigurationManager()
    {
      switch (_Settings.ConfigurationSource)
      {
        case "Config":
          //*********************************************************************
          // Create Configuration Manager and use the Configuration File Provider
          //*********************************************************************
          FWConfigurationManager.Instance =
           new FWConfigurationManager(
             new FWConfigurationConfig(string.Empty));
          break;

        case "Registry":
          //**************************************************************
          // Create Configuration Manager and use the Registry Provider
          //**************************************************************
          FWConfigurationManager.Instance =
           new FWConfigurationManager(
            new FWConfigurationRegistry(_Settings.ConfigurationLocation));
          break;

        case "Xml":
          //**************************************************************
          // Create Configuration Manager and use the Xml Provider
          //**************************************************************
          FWConfigurationManager.Instance =
            new FWConfigurationManager(
              new FWConfigurationXml(
                FWFileCommon.GetCurrentDirectory() + _Settings.ConfigurationLocation));
          break;

        default:
          break;
      }
    }
    #endregion

    #region InitializeMessageManager Method
    protected void InitializeMessageManager()
    {
      switch (_Settings.MessageSource)
      {
        case "Resource":
          if (string.IsNullOrEmpty(_Settings.MessageLocation))
          {
            //**************************************************************
            // Create Message Manager and Default to 'Resource' Provider
            // The resources will come from the current project
            //**************************************************************
            FWMessageManager.Instance =
              new FWMessageManager(new FWMessageResource());
          }
          else
          {
            //**************************************************************
            // Create Message Manager and Pass in Resource Name
            //**************************************************************
            FWMessageManager.Instance =
              new FWMessageManager(
                new FWMessageResource(_Settings.MessageLocation));
          }
          break;

        case "Xml":
          //**************************************************************
          // Create Message Manager and Default to 'XML' Provider
          //**************************************************************
          FWMessageManager.Instance =
            new FWMessageManager(
              new FWMessageXml(_Settings.MessageLocation));

          break;

        default:
          break;
      }
    }
    #endregion

    #region InitializeExceptionManager Method
    protected void InitializeExceptionManager()
    {
      if (_Settings.UseExceptionFilePublisher)
      {
        //**************************************************************
        // Create Exception Manager and Add 'File' Publisher
        //**************************************************************
        FWExceptionManager.Instance.Publishers.Add(
          new FWExceptionToFile(_Settings.ExceptionFileName));
      }

      if (_Settings.UseExceptionEmailPublisher)
      {
        //**************************************************************
        // Create Exception Manager and Add 'Email' Publisher
        //**************************************************************
        FWEmailSettings settings = new FWEmailSettings();
        settings.FromEmail = _Settings.ExceptionEmailFrom;
        settings.ToEmail = _Settings.ExceptionEmailTo;
        settings.Subject = _Settings.ExceptionEmailSubject;
        FWExceptionManager.Instance.Publishers.Add(
          new FWExceptionToEMail(settings));
      }

      if(_Settings.UseExceptionEventLogPublisher)
      {
        FWExceptionManager.Instance.Publishers.Add(
         new FWExceptionToEventLog(_Settings.ExceptionEventLog));
      }

      if(_Settings.UseExceptionTablePublisher)
      {
        FWExceptionManager.Instance.Publishers.Add(
         new FWExceptionToDB(_Settings.ExceptionConnectionString));
      }
    }
    #endregion
  }
}
