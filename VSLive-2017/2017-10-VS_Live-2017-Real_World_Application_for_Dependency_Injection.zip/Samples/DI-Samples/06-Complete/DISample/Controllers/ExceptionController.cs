﻿using System;
using System.Collections.Specialized;
using System.Web.Mvc;
using FW.ExceptionLayer;

namespace DISample.Controllers
{
  public class ExceptionController : Controller
  {
    public ActionResult ExceptionSample()
    {
      return View();
    }

    [HttpPost]
    public ActionResult ExceptionSample(string Command)
    {
      switch (Command)
      {
        case "Publish Exception":
          FWExceptionManager.Instance.Publish(
            new ApplicationException("This is an exception from DISample"));

          break;

        case "Publish Exception with Extras":
          NameValueCollection nvc = new NameValueCollection();
          nvc.Add("DefaultStateCode", "CA");
          nvc.Add("EmpType", "20");

          FWExceptionManager.Instance.Publish(
            new ApplicationException("This is an exception from DISample"), nvc);
          break;

        default:
          break;
      }

      System.Diagnostics.Debugger.Break();

      return View();
    }
  }
}