﻿using System;
using System.IO;
using System.Linq;

namespace FW.Common
{
  /// <summary>
  /// A class for common file methods
  /// </summary>
  public class FWFileCommon
  {
    /// <summary>
    /// Gets the current directory in which your application is running
    /// If you are running in VS.NET it will remove the \bin folder from the path.
    /// </summary>
    /// <returns>The current directory</returns>
    public static string GetCurrentDirectory()
    {
      string path = null;

      path = AppDomain.CurrentDomain.BaseDirectory;
      if (path.IndexOf(@"\bin") > 0)
      {
        path = path.Substring(0, path.LastIndexOf(@"\bin"));
      }
      if (path.EndsWith(@"\"))
        path = path.Substring(0, path.Length - 1);

      return path;
    }
  }
}
