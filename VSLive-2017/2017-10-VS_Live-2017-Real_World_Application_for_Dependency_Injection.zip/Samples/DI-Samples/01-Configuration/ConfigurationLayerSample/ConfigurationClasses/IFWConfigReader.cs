namespace FW.ConfigurationLayer
{
  public interface IFWConfigReader
  {
    string GetSetting(string key);

    string GetSetting(string key, string defaultValue);
  }
}