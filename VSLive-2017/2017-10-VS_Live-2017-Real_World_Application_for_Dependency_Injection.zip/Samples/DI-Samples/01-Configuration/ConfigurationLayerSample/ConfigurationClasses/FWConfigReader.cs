using System.Configuration;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// "Injector" class for reading .Config files
  /// </summary>
  public class FWConfigReader : IFWConfigReader
  {
    public string GetSetting(string key)
    {
      return GetSetting(key, string.Format("The key '{0}' can't be found in config file", key));
    }

    public string GetSetting(string key, string defaultValue)
    {
      string ret;

      ret = ConfigurationManager.AppSettings[key];
      if (ret == null) { 
        ret = defaultValue;
      }

      return ret;
    }
  }
}