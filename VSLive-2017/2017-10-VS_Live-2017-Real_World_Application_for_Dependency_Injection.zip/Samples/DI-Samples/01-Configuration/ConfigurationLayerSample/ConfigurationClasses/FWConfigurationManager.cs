using System;

namespace FW.ConfigurationLayer
{
  /// <summary>
  /// This is the "Dependent" class
  /// </summary>
  public class FWConfigurationManager
  {
    public FWConfigurationManager(IFWConfigReader reader)
    {
      if (reader == null) {
        throw new ArgumentNullException("reader");
      }

      _ConfigReader = reader;
    }

    private IFWConfigReader _ConfigReader = null;
        
    public virtual string GetSetting(string key)
    {
      return _ConfigReader.GetSetting(key);
    }

    public virtual string GetSetting(string key, string defaultValue)
    {
      return _ConfigReader.GetSetting(key, defaultValue);
    }
  }
}