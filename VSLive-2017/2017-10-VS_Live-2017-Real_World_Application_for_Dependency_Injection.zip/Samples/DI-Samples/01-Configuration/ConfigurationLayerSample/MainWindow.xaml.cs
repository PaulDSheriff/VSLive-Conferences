﻿using System.Diagnostics;
using System.Windows;
using FW.ConfigurationLayer;

namespace ConfigurationLayerSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }
    
    private void btnGetSettingInstance_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = 
        new FWConfigurationManager(new FWConfigReader());

      txtValue.Text = mgr.GetSetting(txtKey.Text);
    }
    
    private void btnGetSettingDefault_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr =
      new FWConfigurationManager(new FWConfigReader());

      txtValue.Text = mgr.GetSetting(txtKey.Text, txtDefault.Text);
    }    
  }
}
