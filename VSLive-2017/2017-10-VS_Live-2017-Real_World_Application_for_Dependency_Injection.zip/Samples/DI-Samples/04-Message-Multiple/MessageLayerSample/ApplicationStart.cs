﻿
using FW.MessageLayer;
using FW.Common;

namespace MessageLayerSample
{
  public class ApplicationStart
  {
    #region Instance Property
    private static ApplicationStart _Instance = null;

    public static ApplicationStart Instance
    {
      get
      {
        if (_Instance == null)
          _Instance = new ApplicationStart();

        return _Instance;
      }
      set { _Instance = value; }
    }
    #endregion

    public void Initialize()
    {
      // Initialize Message Manager
      InitializeMessageManager();
    }

    protected void InitializeMessageManager()
    {
      //**************************************************************
      // Create Message Manager and Default to 'Resource' Provider
      // The resources will come from the current project
      //**************************************************************
      //FWMessageManager.Instance = 
      //  new FWMessageManager(new FWMessageResource());

      //**************************************************************
      // Create Message Manager and Pass in Resource Name
      //**************************************************************
      //FWMessageManager.Instance =
      //  new FWMessageManager(
      //    new FWMessageResource("MessageLayerSample.Properties.Resources"));

      //**************************************************************
      // Create Message Manager and Default to 'XML' Provider
      //**************************************************************
      FWMessageManager.Instance =
        new FWMessageManager(
          new FWMessageXml(FWFileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml"));
    }
  }
}
