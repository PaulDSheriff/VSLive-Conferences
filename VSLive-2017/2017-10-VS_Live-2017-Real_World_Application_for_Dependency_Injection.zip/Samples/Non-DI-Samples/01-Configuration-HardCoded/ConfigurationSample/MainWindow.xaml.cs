﻿using System.Windows;
using FW.ConfigurationLayer;

namespace ConfigurationSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Configuration File Samples
    private void btnGetValueConfig_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = new FWConfigurationManager();

      tbResult.Text = mgr.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }
    #endregion
  }
}
