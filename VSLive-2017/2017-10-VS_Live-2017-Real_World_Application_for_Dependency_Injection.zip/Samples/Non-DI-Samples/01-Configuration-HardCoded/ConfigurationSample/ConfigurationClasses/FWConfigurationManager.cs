﻿namespace FW.ConfigurationLayer
{
  public class FWConfigurationManager
  {
    public FWConfigurationManager()
    {
      _ConfigReader = new FWConfigFileReader();
    }

    private FWConfigFileReader _ConfigReader;

    public string GetSetting(string key)
    {
      return GetSetting(key, string.Format("Key {0} Not Found.", key));
    }

    public string GetSetting(string key, string defaultValue)
    {
      return _ConfigReader.GetSetting(key, defaultValue);
    }
  }
}
