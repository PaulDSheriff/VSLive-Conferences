﻿using System.Configuration;

namespace FW.ConfigurationLayer
{
  public class FWConfigFileReader
  {
    /// <summary>
    /// Return the value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <returns>A value</returns>
    public string GetSetting(string key)
    {
      return GetSetting(key, string.Format("Key {0} Not Found.", key));
    }

    /// <summary>
    /// Return a value for the specified key passed in
    /// </summary>
    /// <param name="key">The key to locate</param>
    /// <param name="defaultValue">The default value to return if the key is not found</param>
    /// <returns>A value</returns>
    public string GetSetting(string key, string defaultValue)
    {
      string ret = string.Empty;

      ret = ConfigurationManager.AppSettings[key];
      if (string.IsNullOrEmpty(ret))
        ret = defaultValue;

      return ret;
    }
  }
}
