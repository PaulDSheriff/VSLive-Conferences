﻿using System.Windows;
using FW.Common;
using FW.ConfigurationLayer;

namespace ConfigurationSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Configuration File Samples
    private void btnGetValueConfig_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = new FWConfigurationManager();

      mgr.StorageLocation = FWConfigurationStorageLocation.ConfigFile;

      tbResult.Text = mgr.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }
       
    private void btnGetValueConfigSingleton_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = 
        FWConfigurationManager.Instance.GetSetting(txtKey.Text,
        txtDefaultValue.Text, 
        FWConfigurationStorageLocation.ConfigFile);
    }
    #endregion

    #region Xml File Samples
    private void btnGetValueXml_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = new FWConfigurationManager();

      mgr.StorageLocation = FWConfigurationStorageLocation.Xml;
      mgr.Location = FWFileCommon.GetCurrentDirectory() + @"\Settings.xml";

      tbResult.Text = mgr.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }

    private void btnGetValueXmlSingleton_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = FWConfigurationManager.Instance.GetSetting(
        txtKey.Text, 
        txtDefaultValue.Text,
        FWConfigurationStorageLocation.Xml, 
        FWFileCommon.GetCurrentDirectory() + @"\Settings.xml");
    }
    #endregion

    #region Registry Samples
    private void btnGetValueRegistry_Click(object sender, RoutedEventArgs e)
    {
      FWConfigurationManager mgr = new FWConfigurationManager();

      mgr.StorageLocation = FWConfigurationStorageLocation.Registry;
      mgr.Location = @"Software\MyApp";

      tbResult.Text = mgr.GetSetting(txtKey.Text, txtDefaultValue.Text);
    }

    private void btnGetValueRegistrySingleton_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = 
        FWConfigurationManager.Instance.GetSetting(txtKey.Text, 
        txtDefaultValue.Text, 
        FWConfigurationStorageLocation.Registry,
        @"Software\MyApp");
    }
    #endregion
  }
}
