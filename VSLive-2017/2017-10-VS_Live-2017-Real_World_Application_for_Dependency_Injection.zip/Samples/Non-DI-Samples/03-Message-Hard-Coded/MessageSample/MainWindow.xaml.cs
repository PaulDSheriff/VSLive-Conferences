﻿using System.Windows;
using FW.Common;
using FW.MessageLayer;

namespace MessageSample
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    private void btnGetMessageXml_Click(object sender, RoutedEventArgs e)
    {
      MessageManager mgr = 
        new MessageManager(FWFileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml");

      tbResult.Text = mgr.GetMessage(txtKey.Text, txtDefaultMsg.Text);
    }
  }
}
