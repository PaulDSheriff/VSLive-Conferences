﻿using System;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Xml.Linq;

namespace FW.MessageLayer
{
  public class MessageManager
  {
    public MessageManager(string location)
    {
      _MessageReader = new MessageXML(location);
    }

    private MessageXML _MessageReader;

    public string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Resource {0} Not Found.", key));
    }

    public string GetMessage(string key, string defaultMessage)
    {    
      return _MessageReader.GetMessage(key, defaultMessage);
    }
  }
}
