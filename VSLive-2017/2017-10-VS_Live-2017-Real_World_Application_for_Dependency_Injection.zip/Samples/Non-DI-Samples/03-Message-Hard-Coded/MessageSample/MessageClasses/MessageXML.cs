﻿using System.Linq;
using System.Xml.Linq;

namespace FW.MessageLayer
{
  public class MessageXML
  {
    public MessageXML(string location)
    {
      _Location = location;
    }

    private string _Location;

    public string GetMessage(string key)
    {
      return GetMessage(key, string.Format("Resource {0} Not Found.", key));
    }

    public string GetMessage(string key, string defaultMessage)
    {
      string ret = defaultMessage;

      XElement doc = XElement.Load(_Location);

      XElement elem = (from node in doc.Elements("Message")
                       where node.Element("Key").Value == key
                       select node).SingleOrDefault();

      if (elem != null)
        ret = elem.Element("Value").Value;

      return ret;
    }
  }
}
