﻿using System.Windows;
using FW.Common;
using FW.MessageLayer;

namespace MessageSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    #region Get Messages from Resource File
    private void btnGetMessageResource_Click(object sender, RoutedEventArgs e)
    {
      MessageManager mgr = new MessageManager();

      mgr.StorageLocation = MessageStorageLocation.Resource;

      tbResult.Text = mgr.GetMessage(txtKey.Text, txtDefaultMsg.Text);
    }

    private void btnGetMessageSingletonResource_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = MessageManager.Instance.GetMessage(
        txtKey.Text, 
        txtDefaultMsg.Text, 
        MessageStorageLocation.Resource);
    }
    #endregion

    #region Get Messages from Xml File
    private void btnGetMessageXml_Click(object sender, RoutedEventArgs e)
    {
      MessageManager mgr = new MessageManager();

      mgr.StorageLocation = MessageStorageLocation.Xml;
      mgr.Location = FWFileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml";

      tbResult.Text = mgr.GetMessage(txtKey.Text, txtDefaultMsg.Text);
    }

    private void btnGetMessageSingletonXml_Click(object sender, RoutedEventArgs e)
    {
      tbResult.Text = MessageManager.Instance.GetMessage(
       txtKey.Text,
       txtDefaultMsg.Text,
       MessageStorageLocation.Xml,
       FWFileCommon.GetCurrentDirectory() + @"\Xml\Messages.xml");
    }
    #endregion
  }
}
