﻿using System.Windows;

namespace WPFSecurityBindingSample
{
  public partial class App : Application
  {
  }
}
