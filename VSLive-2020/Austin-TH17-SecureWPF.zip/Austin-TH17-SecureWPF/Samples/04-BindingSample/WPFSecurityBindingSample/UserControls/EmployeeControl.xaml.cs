﻿using System.Windows.Controls;

namespace WPFSecurityBindingSample
{
  public partial class EmployeeControl : UserControl
  {
    public EmployeeControl()
    {
      InitializeComponent();
    }
  }
}
