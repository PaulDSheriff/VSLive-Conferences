﻿WPF Security Sample
--------------------------------
This sample shows how to secure controls on a WPF element.
Controls may be secured by disabling, making them readonly, hidden, or collapsed.

To identify the controls to be secured, create a collection of SecurityControl objects.
	In each SecurityControl object, fill in the following properties:
	- ElementIdentifier: Name of the control | The binding Path | Value in the Tag property
	- Mode: disabled | readonly | hidden | collapsed
	- RolesAsString: Comma-delimited list of roles user must be in to show control normally