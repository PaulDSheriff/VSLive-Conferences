﻿using System.Windows;

namespace WPFSecurityPropertySample
{
  public partial class App : Application
  {   
  }
}
