﻿WPF Security Sample
--------------------------------
This sample shows how to secure controls on a WPF element using properties in the view model class.

