﻿using System.Security.Principal;

namespace Common.Library
{
  public class AppSecurityViewModelBase : CommonBase
  {
    #region Properties
    private bool _IsInUsersRole;
    private bool _IsInAdminRole;
    private bool _IsInSupervisorRole;

    /// <summary>
    /// Get/Set IsInUsersRole
    /// </summary>
    public bool IsInUsersRole
    {
      get { return _IsInUsersRole; }
      set {
        _IsInUsersRole = value;
        RaisePropertyChanged("IsInUsersRole");
        RaisePropertyChanged("IsInUsersOrSupervisorRole");
      }
    }

    /// <summary>
    /// Get/Set IsInAdminRole
    /// </summary>
    public bool IsInAdminRole
    {
      get { return _IsInAdminRole; }
      set {
        _IsInAdminRole = value;
        RaisePropertyChanged("IsInAdminRole");
        RaisePropertyChanged("IsInAdminOrSupervisorRole");
      }
    }

    /// <summary>
    /// Get/Set IsInSupervisorRole
    /// </summary>
    public bool IsInSupervisorRole
    {
      get { return _IsInSupervisorRole; }
      set {
        _IsInSupervisorRole = value;
        RaisePropertyChanged("IsInSupervisorRole");
        RaisePropertyChanged("IsInUsersOrSupervisorRole");
        RaisePropertyChanged("IsInAdminOrSupervisorRole");
      }
    }
    
    /// <summary>
    /// Get/Set IsInUsersOrSupervisorRole
    /// </summary>
    public bool IsInUsersOrSupervisorRole
    {
      get { return _IsInUsersRole || _IsInSupervisorRole; }
      set {
        RaisePropertyChanged("IsInUsersOrSupervisorRole");
      }
    }

    /// <summary>
    /// Get/Set IsInAdminOrSupervisorRole
    /// </summary>
    public bool IsInAdminOrSupervisorRole
    {
      get { return _IsInSupervisorRole || _IsInAdminRole; }
      set {
        RaisePropertyChanged("IsInAdminOrSupervisorRole");
      }
    }
    #endregion

    #region SecureControls Method
    public void SecureControls()
    {
      IPrincipal prin = System.Threading.Thread.CurrentPrincipal;

      IsInUsersRole = prin.IsInRole("Users");
      IsInAdminRole = prin.IsInRole("Administrators");
      IsInSupervisorRole = prin.IsInRole("Supervisor");
    }
    #endregion
  }
}