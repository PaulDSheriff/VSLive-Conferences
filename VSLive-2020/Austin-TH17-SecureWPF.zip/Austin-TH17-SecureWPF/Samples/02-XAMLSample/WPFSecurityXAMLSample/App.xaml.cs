﻿using System.Windows;

namespace WPFSecurityXAMLSample
{
  public partial class App : Application
  {
  }
}
