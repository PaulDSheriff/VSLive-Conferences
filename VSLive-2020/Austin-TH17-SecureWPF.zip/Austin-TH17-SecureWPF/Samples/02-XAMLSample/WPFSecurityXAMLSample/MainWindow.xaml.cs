﻿using System.Windows;
using WPFSecurityXAMLSample.ViewModels;

namespace WPFSecurityXAMLSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      _viewModel = (EmployeeViewModel)this.Resources["viewModel"];
    }

    private readonly EmployeeViewModel _viewModel;

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _viewModel.SecureControls(this, string.Empty);
    }
  }
}
