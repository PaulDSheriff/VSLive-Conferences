﻿using System.Collections.Generic;
using System.Security.Principal;
using System.Threading;
using System.Windows;
using System.Windows.Controls;

namespace WPF.Security
{
  public class SecurityViewModelBase
  {
    #region Constructor
    public SecurityViewModelBase()
    {
      ControlsToSecure = new List<SecurityControl>();
      ControlsInContainer = new List<XAMLControlInfo>();
    }
    #endregion

    #region Properties
    public List<SecurityControl> ControlsToSecure { get; set; }
    public List<XAMLControlInfo> ControlsInContainer { get; set; }
    public IPrincipal CurrentPrincipal { get; set; }
    #endregion

    #region SecureControls Method
    /// <summary>
    /// Secure controls within the XAML element passed in
    /// </summary>
    /// <param name="element">A WPF Control such as a Window, User Control, Grid or StackPanel</param>
    /// <param name="containerName">The name of a Window or User Control you wish to secure.</param>
    public virtual void SecureControls(object element, string containerName)
    {
      XAMLControlInfo ctl = null;

      // Get Current Principal
      CurrentPrincipal = Thread.CurrentPrincipal;

      // Get Controls to Secure from Data Store
      LoadControlsToSecure(containerName);

      // Build List of Controls in XAML Element to be Secured
      LoadControlsInXAMLContainer(element);

      // Loop through controls
      foreach (SecurityControl secCtl in ControlsToSecure) {
        secCtl.ElementIdentifier = secCtl.ElementIdentifier.ToLower();
        // Search for Name property
        ctl = ControlsInContainer.Find(c => c.ControlName.ToLower() == secCtl.ElementIdentifier);
        if (ctl == null) {
          // Search for Tag property
          ctl = ControlsInContainer.Find(c => c.Tag.ToLower() == secCtl.ElementIdentifier);
        }
        if (ctl != null && !string.IsNullOrWhiteSpace(secCtl.Mode)) {
          // Loop through roles and see if user is NOT in one of the roles
          // If they are not, then change the state of the control
          foreach (string role in secCtl.Roles) {
            if (CurrentPrincipal.IsInRole(role)) {
              // They are in a role, so break out of loop
              break;
            }
            else {
              // They are NOT in a role, so change the control state
              ChangeState(ctl, secCtl.Mode);
              // Break out of loop because we have already modified the control state
              break;
            }
          }
        }
      }
    }
    #endregion

    #region ChangeState Method
    /// <summary>
    /// Sets a control's state based on the mode passed in.
    /// </summary>
    /// <param name="control">A Control object</param>
    /// <param name="mode">The mode to set</param>
    protected virtual void ChangeState(XAMLControlInfo control, string mode)
    {
      Control ctl = (Control)control.TheControl;

      switch (mode.ToLower()) {
        case "disabled":
          ctl.Visibility = Visibility.Visible;
          ctl.IsEnabled = false;
          break;
        case "readonly":
        case "read only":
        case "read-only":
          ctl.Visibility = Visibility.Visible;
          ctl.IsEnabled = true;
          if (control.HasIsReadOnlyProperty) {
            // Use reflection to turn on IsReadOnly property
            ctl.GetType().GetProperty("IsReadOnly").SetValue(control.TheControl, true, null);
          }
          else {
            ctl.IsEnabled = false;
          }
          break;
        case "collapsed":
        case "collapse":
          ctl.Visibility = Visibility.Collapsed;
          break;
        case "hidden":
        case "invisible":
          ctl.Visibility = Visibility.Hidden;
          break;
      }
    }
    #endregion

    #region LoadControlsToSecure Method
    /// <summary>
    /// Override this method to gather the list of controls to secure from a data store.
    /// The 'containerName' parameter allows you to specify the name of a XAML container within which is a list of controls to secure.
    /// </summary>
    /// <param name="containerName">The name of the XAML container you wish to secure.</param>
    protected virtual void LoadControlsToSecure(string containerName)
    {
    }
    #endregion

    #region LoadControlsInXAMLContainer Method
    /// <summary>
    /// Create a collection of controls from the WPF Window/User Control, etc. that is passed in.
    /// For example, you might pass in a Grid or StackPanel, and this method will 
    /// fill in the 'ControlsInContainer' property.
    /// </summary>
    /// <param name="element">A WPF Container control such as a Window, User Control, Grid or StackPanel</param>
    protected virtual void LoadControlsInXAMLContainer(object element)
    {
      XAMLControlInfo ctl;
      FrameworkElement fe;

      if (element is DependencyObject dep) {
        ctl = new XAMLControlInfo
        {
          TheControl = element,
          ControlType = element.GetType().Name
        };

        // Cast to 'FrameworkElement' so we can get the Name and Tag properties
        fe = element as FrameworkElement;
        if (fe != null) {
          ctl.ControlName = fe.Name;
          if (fe.Tag != null) {
            ctl.Tag = fe.Tag.ToString();
          }
        }

        if (ctl.ConsiderForSecurity()) {
          // Is there a ReadOnly property?
          ctl.HasIsReadOnlyProperty = element.GetType().GetProperty("IsReadOnly") == null ? false : true;

          // Make sure there is not a null in ControlName or Tag
          ctl.ControlName = ctl.ControlName ?? string.Empty;
          ctl.Tag = ctl.Tag ?? string.Empty;

          // Add control to be considered for security
          ControlsInContainer.Add(ctl);
        }

        // Look for Child objects
        foreach (object child in LogicalTreeHelper.GetChildren(dep)) {
          // Make recursive call
          LoadControlsInXAMLContainer(child);
        }
      }
    }
    #endregion
  }
}
