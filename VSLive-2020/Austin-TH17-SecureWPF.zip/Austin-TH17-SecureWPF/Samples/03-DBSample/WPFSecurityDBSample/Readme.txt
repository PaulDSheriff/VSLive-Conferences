﻿WPF Security Sample
--------------------------------
This sample shows how to secure controls on a WPF element.
Controls may be secured by disabling, making them readonly, hidden, or collapsed
To identify the controls to be secured, create a collection of SecurityControl objects
	In each SecurityControl object, fill in the following properties
	- ElementIdentifier: Name of the control | The binding Path | Value in the Tag property
	- Mode: disabled | readonly | hidden | collapsed
	- RolesAsString: Comma-delimited list of roles user must be in to show control normally
  

Changes from previous Security sample
-----------------------------------------------------
Added Entity Framework to the project
Added SecurityControlId property to SecurityControl class
Added [Table] attribute to SecurityControl class
Added WPFSecurityDbContext class to connect to database
Added SecurityControlManager class to get controls to secure from database
Modified EmployeeViewModel.LoadControlsToSecure() method to use SecurityControlManager to build collection of security controls


SQL Script
----------------
There is a SecurityControl.sql file in the \SqlScripts folder which builds the SecurityControl table which holds the data for the controls to secure

You will have to change the connection string in App.config to run this sample.